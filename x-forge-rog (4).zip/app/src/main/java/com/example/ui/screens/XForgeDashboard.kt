package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.*
import com.example.ui.components.CrosshairDrawing
import com.example.viewmodel.XForgeViewModel
import com.example.overlay.OverlayManager

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun XForgeDashboard(
    viewModel: XForgeViewModel,
    modifier: Modifier = Modifier,
    onRequestPermission: () -> Unit
) {
    val context = LocalContext.current
    val currentProfile by viewModel.currentProfile.collectAsStateWithLifecycle()
    val savedProfiles by viewModel.savedProfiles.collectAsStateWithLifecycle()

    val fps by viewModel.fps.collectAsStateWithLifecycle()
    val cpuTemp by viewModel.cpuTemp.collectAsStateWithLifecycle()
    val ramUsage by viewModel.ramUsage.collectAsStateWithLifecycle()
    val isBoosting by viewModel.isBoosting.collectAsStateWithLifecycle()
    val boostProgress by viewModel.boostProgress.collectAsStateWithLifecycle()

    val isOverlayActive by OverlayManager.isOverlayActive.collectAsStateWithLifecycle()

    var showSaveDialog by remember { mutableStateOf(false) }
    var showProfilesDialog by remember { mutableStateOf(false) }
    var newProfileName by remember { mutableStateOf("") }

    // Pulsing animation for system active dot
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(RogBgDark)
    ) {
        // --- 1. ROG SYSTEM HEADER ---
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // System active indicator
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(RogRed.copy(alpha = pulseAlpha))
                    )
                    Text(
                        text = "SYSTEM ACTIVE",
                        color = RogRed,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 2.sp
                    )
                }

                // Stats Row
                Row(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "CPU $cpuTemp°C",
                        color = RogTextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "$fps FPS",
                        color = RogGreen,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Main Title
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "X-FORGE ",
                    color = RogWhite,
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Black,
                    fontStyle = FontStyle.Italic,
                    fontFamily = FontFamily.SansSerif
                )
                Text(
                    text = "ROG",
                    color = RogRed,
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Black,
                    fontStyle = FontStyle.Italic,
                    fontFamily = FontFamily.SansSerif,
                    modifier = Modifier.drawBehind {
                        drawLine(
                            color = RogRed,
                            start = Offset(0f, size.height - 4.dp.toPx()),
                            end = Offset(size.width, size.height - 4.dp.toPx()),
                            strokeWidth = 3.dp.toPx()
                        )
                    }
                )
            }
            Text(
                text = "Gaming Utility & Overlay Engine",
                color = RogTextMuted,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                fontFamily = FontFamily.SansSerif,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        // --- 2. PREVIEW CANVAS AREA ---
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(RogSurface.copy(alpha = 0.4f))
                .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(24.dp)),
            contentAlignment = Alignment.Center
        ) {
            // Draw background glowing radar grid lines
            Canvas(modifier = Modifier.fillMaxSize()) {
                val center = Offset(size.width / 2, size.height / 2)
                // Radar circles
                drawCircle(
                    color = RogRed.copy(alpha = 0.06f),
                    radius = 80.dp.toPx(),
                    center = center,
                    style = Stroke(width = 1.dp.toPx())
                )
                drawCircle(
                    color = RogRed.copy(alpha = 0.03f),
                    radius = 140.dp.toPx(),
                    center = center,
                    style = Stroke(width = 1.dp.toPx())
                )
                // Grid lines
                drawLine(
                    color = RogRed.copy(alpha = 0.04f),
                    start = Offset(0f, center.y),
                    end = Offset(size.width, center.y),
                    strokeWidth = 1.dp.toPx()
                )
                drawLine(
                    color = RogRed.copy(alpha = 0.04f),
                    start = Offset(center.x, 0f),
                    end = Offset(center.x, size.height),
                    strokeWidth = 1.dp.toPx()
                )
            }

            // Central crosshair drawing wrapper
            Box(
                modifier = Modifier
                    .size(192.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(RogBgDark.copy(alpha = 0.6f))
                    .border(1.dp, Color.White.copy(alpha = 0.07f), RoundedCornerShape(20.dp)),
                contentAlignment = Alignment.Center
            ) {
                // Interactive Grid background
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .drawBehind {
                            val step = 16.dp.toPx()
                            var x = step
                            while (x < size.width) {
                                drawLine(
                                    color = Color.White.copy(alpha = 0.02f),
                                    start = Offset(x, 0f),
                                    end = Offset(x, size.height),
                                    strokeWidth = 0.5.dp.toPx()
                                )
                                x += step
                            }
                            var y = step
                            while (y < size.height) {
                                drawLine(
                                    color = Color.White.copy(alpha = 0.02f),
                                    start = Offset(0f, y),
                                    end = Offset(size.width, y),
                                    strokeWidth = 0.5.dp.toPx()
                                )
                                y += step
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    CrosshairDrawing(profile = currentProfile)
                }

                // Decorative Corner Labels
                Text(
                    text = "PREVIEW_MODE",
                    color = Color.White.copy(alpha = 0.4f),
                    fontSize = 8.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(10.dp)
                )

                Text(
                    text = "${currentProfile.size.toInt()}px | ${String.format("%.1f", currentProfile.opacity)}α",
                    color = Color.White.copy(alpha = 0.4f),
                    fontSize = 8.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(10.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // --- 3. CONFIGURATION SHEET ---
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp)),
            color = RogSurface,
            tonalElevation = 8.dp
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
                    .padding(top = 24.dp, bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                // Header of configuration + Profile Options
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Crosshair Config",
                                color = RogWhite,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Customize your primary overlay",
                                color = RogTextSecondary,
                                fontSize = 11.sp
                            )
                        }

                        // Profile Actions Row
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Saved List Button
                            IconButton(
                                onClick = { showProfilesDialog = true },
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color.White.copy(alpha = 0.05f))
                            ) {
                                Icon(
                                    imageVector = Icons.Default.List,
                                    contentDescription = "Profiles",
                                    tint = RogWhite,
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            Button(
                                onClick = {
                                    newProfileName = ""
                                    showSaveDialog = true
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = RogRed),
                                shape = RoundedCornerShape(12.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                modifier = Modifier.height(36.dp).testTag("save_profile_button")
                            ) {
                                Text(
                                    text = "SAVE PROFILE",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 0.5.sp
                                )
                            }
                        }
                    }
                }

                // Shape selection layout
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Shape Style",
                                color = RogTextSecondary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                            Text(
                                text = currentProfile.shape,
                                color = RogRed,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            val shapes = listOf(
                                "CLASSIC_X" to "Cross",
                                "DOT" to "Dot",
                                "SQUARE" to "Square",
                                "CIRCLE" to "Circle"
                            )

                            shapes.forEach { (type, label) ->
                                val selected = currentProfile.shape == type
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(44.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(
                                            if (selected) RogRed.copy(alpha = 0.15f)
                                            else Color.White.copy(alpha = 0.04f)
                                        )
                                        .border(
                                            width = 1.dp,
                                            color = if (selected) RogRed.copy(alpha = 0.5f)
                                            else Color.Transparent,
                                            shape = RoundedCornerShape(12.dp)
                                        )
                                        .clickable { viewModel.updateShape(type) }
                                        .testTag("shape_${type.lowercase()}_button"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = label,
                                        color = if (selected) RogRed else RogTextSecondary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                // Size slider layout
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Crosshair Size",
                                color = RogTextSecondary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${currentProfile.size.toInt()} px",
                                color = RogTextPrimary,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Slider(
                            value = currentProfile.size,
                            onValueChange = { viewModel.updateSize(it) },
                            valueRange = 10f..120f,
                            colors = SliderDefaults.colors(
                                thumbColor = RogWhite,
                                activeTrackColor = RogRed,
                                inactiveTrackColor = Color.White.copy(alpha = 0.08f)
                            ),
                            modifier = Modifier.testTag("size_slider")
                        )
                    }
                }

                // Weight / Thickness slider
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Line Weight",
                                color = RogTextSecondary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${currentProfile.thickness.toInt()} dp",
                                color = RogTextPrimary,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Slider(
                            value = currentProfile.thickness,
                            onValueChange = { viewModel.updateThickness(it) },
                            valueRange = 1f..12f,
                            colors = SliderDefaults.colors(
                                thumbColor = RogWhite,
                                activeTrackColor = RogRed,
                                inactiveTrackColor = Color.White.copy(alpha = 0.08f)
                            ),
                            modifier = Modifier.testTag("weight_slider")
                        )
                    }
                }

                // Gap slider (Not relevant for Dot, but highly relevant for Classic/Circle)
                if (currentProfile.shape != "DOT") {
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Inner Clearance (Gap)",
                                    color = RogTextSecondary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${currentProfile.gap.toInt()} px",
                                    color = RogTextPrimary,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }

                            Slider(
                                value = currentProfile.gap,
                                onValueChange = { viewModel.updateGap(it) },
                                valueRange = 0f..30f,
                                colors = SliderDefaults.colors(
                                    thumbColor = RogWhite,
                                    activeTrackColor = RogRed,
                                    inactiveTrackColor = Color.White.copy(alpha = 0.08f)
                                ),
                                modifier = Modifier.testTag("gap_slider")
                            )
                        }
                    }
                }

                // Opacity slider
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Opacity",
                                color = RogTextSecondary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${(currentProfile.opacity * 100).toInt()}%",
                                color = RogTextPrimary,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Slider(
                            value = currentProfile.opacity,
                            onValueChange = { viewModel.updateOpacity(it) },
                            valueRange = 0.1f..1.0f,
                            colors = SliderDefaults.colors(
                                thumbColor = RogWhite,
                                activeTrackColor = RogRed,
                                inactiveTrackColor = Color.White.copy(alpha = 0.08f)
                            ),
                            modifier = Modifier.testTag("opacity_slider")
                        )
                    }
                }

                // Tactical Colors Row
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "Tactical Color Accent",
                            color = RogTextSecondary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )

                        val colors = listOf(
                            "#EF4444" to RogRed,     // Radiant Red
                            "#10B981" to RogGreen,   // Cyber Green
                            "#06B6D4" to RogCyan,    // Neon Cyan
                            "#EAB308" to RogYellow,  // Tactic Yellow
                            "#3B82F6" to RogBlue,    // Hyper Blue
                            "#FFFFFF" to RogWhite    // Standard White
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            colors.forEach { (hex, composeColor) ->
                                val selected = currentProfile.colorHex.equals(hex, ignoreCase = true)
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clickable { viewModel.updateColor(hex) }
                                        .testTag("color_${hex.replace("#", "")}_button"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(32.dp)
                                            .clip(CircleShape)
                                            .background(composeColor)
                                            .border(
                                                width = if (selected) 3.dp else 1.dp,
                                                color = if (selected) RogWhite else Color.White.copy(alpha = 0.2f),
                                                shape = CircleShape
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (selected) {
                                            Box(
                                                modifier = Modifier
                                                    .size(8.dp)
                                                    .clip(CircleShape)
                                                    .background(RogBgDark)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // RAM Booster Panel
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color.White.copy(alpha = 0.03f))
                            .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(16.dp))
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "System RAM Booster",
                                    color = RogWhite,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Active: $ramUsage",
                                    color = RogTextSecondary,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )

                                AnimatedVisibility(visible = isBoosting) {
                                    Column(modifier = Modifier.padding(top = 8.dp)) {
                                        Text(
                                            text = "Optimizing JVM Memory...",
                                            color = RogRed,
                                            fontSize = 9.sp,
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        LinearProgressIndicator(
                                            progress = { boostProgress },
                                            color = RogRed,
                                            trackColor = Color.White.copy(alpha = 0.05f),
                                            modifier = Modifier.width(120.dp).height(4.dp)
                                        )
                                    }
                                }
                            }

                            Button(
                                onClick = { viewModel.triggerMemoryBoost() },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isBoosting) Color.Gray else RogRed.copy(alpha = 0.15f),
                                    contentColor = if (isBoosting) Color.DarkGray else RogRed
                                ),
                                border = BorderStroke(1.dp, if (isBoosting) Color.Transparent else RogRed.copy(alpha = 0.4f)),
                                shape = RoundedCornerShape(8.dp),
                                enabled = !isBoosting,
                                modifier = Modifier.height(36.dp).testTag("boost_memory_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Boost",
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (isBoosting) "BOOSTING" else "BOOST",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                    }
                }

                // Main Toggle service button
                item {
                    Button(
                        onClick = onRequestPermission,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isOverlayActive) RogRedDark else RogRed
                        ),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("toggle_overlay_button")
                    ) {
                        Text(
                            text = if (isOverlayActive) "STOP OVERLAY SERVICE" else "ACTIVATE FLOATING OVERLAY",
                            color = RogWhite,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }
        }
    }

    // Dialogs / Sheet Implementations

    // 1. Save Dialog
    if (showSaveDialog) {
        Dialog(onDismissRequest = { showSaveDialog = false }) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(24.dp),
                color = RogSurface,
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f))
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Save Crosshair Profile",
                        color = RogWhite,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Store current configurations as custom preset profile",
                        color = RogTextSecondary,
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    TextField(
                        value = newProfileName,
                        onValueChange = { newProfileName = it },
                        placeholder = { Text("E.g., Valorant Dot", color = RogTextMuted, fontSize = 13.sp) },
                        colors = TextFieldDefaults.colors(
                            focusedTextColor = RogWhite,
                            unfocusedTextColor = RogWhite,
                            focusedContainerColor = RogBgDark,
                            unfocusedContainerColor = RogBgDark,
                            focusedIndicatorColor = RogRed,
                            unfocusedIndicatorColor = Color.Transparent
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().testTag("profile_name_input")
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = { showSaveDialog = false },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.05f)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Cancel", color = RogTextSecondary)
                        }

                        Button(
                            onClick = {
                                if (newProfileName.isNotBlank()) {
                                    viewModel.createAndSaveNewProfile(newProfileName)
                                    showSaveDialog = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = RogRed),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f).testTag("dialog_save_confirm")
                        ) {
                            Text("Save", color = RogWhite)
                        }
                    }
                }
            }
        }
    }

    // 2. Saved Profiles List Dialog
    if (showProfilesDialog) {
        Dialog(onDismissRequest = { showProfilesDialog = false }) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .heightIn(max = 450.dp),
                shape = RoundedCornerShape(24.dp),
                color = RogSurface,
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f))
            ) {
                Column(
                    modifier = Modifier.padding(24.dp)
                ) {
                    Text(
                        text = "Saved Profiles",
                        color = RogWhite,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    if (savedProfiles.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth(),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "No custom profiles found.",
                                color = RogTextMuted,
                                fontSize = 13.sp
                            )
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(savedProfiles) { profile ->
                                val active = profile.id == currentProfile.id
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(if (active) RogRed.copy(alpha = 0.08f) else Color.White.copy(alpha = 0.03f))
                                        .border(
                                            1.dp,
                                            if (active) RogRed.copy(alpha = 0.3f) else Color.Transparent,
                                            RoundedCornerShape(12.dp)
                                        )
                                        .clickable {
                                            viewModel.selectProfile(profile)
                                            showProfilesDialog = false
                                        }
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = profile.name,
                                            color = if (active) RogRed else RogWhite,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = "${profile.shape} | Size ${profile.size.toInt()}px | ${profile.colorHex}",
                                            color = RogTextSecondary,
                                            fontSize = 10.sp,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }

                                    IconButton(
                                        onClick = { viewModel.deleteProfile(profile) },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "Delete",
                                            tint = RogTextMuted,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { showProfilesDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.05f)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Close", color = RogTextSecondary)
                    }
                }
            }
        }
    }
}
