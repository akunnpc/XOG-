package com.example.shizuku

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.ParcelFileDescriptor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import moe.shizuku.server.IShizukuService
import rikka.shizuku.Shizuku

sealed class ShizukuResult {
    data class Success(val output: String) : ShizukuResult()
    data class Error(val message: String, val exitCode: Int? = null) : ShizukuResult()
}

object ShizukuManager {
    
    const val REQUEST_CODE_SHIZUKU = 1010
    private const val TAG = "ShizukuManager"

    // Listeners for Shizuku binder and permission events to ensure correct live synchronization
    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        android.util.Log.d(TAG, "[Shizuku Stage] Binder Available: true (via onBinderReceived callback)")
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        android.util.Log.e(TAG, "[Shizuku Stage] Binder Available: false (via onBinderDead callback)")
    }

    private val permissionResultListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        val granted = grantResult == PackageManager.PERMISSION_GRANTED
        android.util.Log.d(TAG, "[Shizuku Stage] Permission Granted: $granted (via onRequestPermissionResult, requestCode=$requestCode)")
    }

    init {
        try {
            android.util.Log.d(TAG, "[Shizuku Init] Registering Shizuku binder received, dead, and permission listeners sticky")
            Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
            Shizuku.addBinderDeadListener(binderDeadListener)
            Shizuku.addRequestPermissionResultListener(permissionResultListener)
        } catch (e: Throwable) {
            android.util.Log.e(TAG, "[Shizuku Init] Failed to register Shizuku listeners", e)
        }
    }

    /**
     * Explicitly triggers static initialization and listener registration.
     */
    fun init() {
        android.util.Log.d(TAG, "[Shizuku Init] ShizukuManager initialized successfully.")
    }

    /**
     * Checks if the Shizuku manager app is installed on the device.
     */
    fun isShizukuInstalled(context: Context): Boolean {
        val installed = try {
            context.packageManager.getPackageInfo("moe.shizuku.privileged.api", 0)
            true
        } catch (e: Exception) {
            false
        }
        android.util.Log.d(TAG, "[Shizuku Stage] Shizuku Installed: $installed")
        return installed
    }

    /**
     * Checks if Shizuku service is running.
     */
    fun isShizukuRunning(): Boolean {
        val running = try {
            Shizuku.pingBinder()
        } catch (e: Throwable) {
            false
        }
        android.util.Log.d(TAG, "[Shizuku Stage] Binder Available: $running")
        return running
    }

    /**
     * Checks if permission is granted to our app to use Shizuku.
     */
    fun hasPermission(): Boolean {
        if (!isShizukuRunning()) {
            android.util.Log.d(TAG, "[Shizuku Stage] Permission Granted: false (Shizuku not running)")
            return false
        }
        val granted = try {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (e: Throwable) {
            false
        }
        android.util.Log.d(TAG, "[Shizuku Stage] Permission Granted: $granted")
        return granted
    }

    /**
     * Requests Shizuku permission.
     */
    fun requestPermission(requestCode: Int = REQUEST_CODE_SHIZUKU) {
        if (isShizukuRunning()) {
            try {
                Shizuku.requestPermission(requestCode)
            } catch (e: Throwable) {
                e.printStackTrace()
            }
        }
    }

    /**
     * Gets intent to launch the main Shizuku app.
     */
    fun getLaunchShizukuIntent(context: Context): Intent? {
        return context.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
    }

    /**
     * Validates if a command is safe to execute.
     * Restricts dangerous write/delete/reboot operations.
     */
    fun isSafeCommand(command: String): Boolean {
        val trimmed = command.trim().lowercase()
        if (trimmed.isEmpty()) return false
        
        val dangerousKeywords = listOf(
            "rm ", "rmdir", "mkfs", "reboot", "shutdown", "dd ", "chmod", 
            "chown", "mv ", "write ", "settings put", "pm install", 
            "pm uninstall", "monkey", "kill", "format", "wipe", "fastboot", 
            "su ", "sh ", "busybox", "fstrim"
        )
        
        return dangerousKeywords.none { trimmed.contains(it) }
    }

    /**
     * Executes a system command via Shizuku shell.
     */
    suspend fun executeCommand(command: String): ShizukuResult = withContext(Dispatchers.IO) {
        val running = isShizukuRunning()
        val permission = hasPermission()
        val safe = isSafeCommand(command)
        val ready = running && permission && safe
        
        android.util.Log.d(TAG, "[Shizuku Stage] Command Ready: $ready for query: '$command'")

        if (!running) {
            return@withContext ShizukuResult.Error("Shizuku is not running. Please start Shizuku app first.")
        }
        if (!permission) {
            return@withContext ShizukuResult.Error("Shizuku permission not granted. Please grant permission.")
        }
        if (!safe) {
            return@withContext ShizukuResult.Error("Command blocked: Execute command is restricted to safe, read-only system queries.")
        }

        try {
            val binder = try { Shizuku.getBinder() } catch (e: Throwable) { null }
            val connected = binder != null
            android.util.Log.d(TAG, "[Shizuku Stage] Service Connected: $connected")

            if (binder == null) {
                return@withContext ShizukuResult.Error("Failed to get Shizuku Binder. Check connection.")
            }
            
            val service = IShizukuService.Stub.asInterface(binder)
                ?: return@withContext ShizukuResult.Error("Failed to access Shizuku Service Interface.")

            // Execute the command in sh shell context
            val remoteProcess = service.newProcess(arrayOf("sh", "-c", command), null, null)
                ?: return@withContext ShizukuResult.Error("Failed to spawn process in Shizuku.")

            // Read output and error streams safely in parallel to prevent deadlocks
            val outputText = coroutineScope {
                val outDeferred = async {
                    try {
                        val pfd = remoteProcess.getInputStream()
                        if (pfd != null) {
                            ParcelFileDescriptor.AutoCloseInputStream(pfd).bufferedReader().use { it.readText() }
                        } else ""
                    } catch (e: Exception) {
                        ""
                    }
                }
                val errDeferred = async {
                    try {
                        val pfd = remoteProcess.getErrorStream()
                        if (pfd != null) {
                            ParcelFileDescriptor.AutoCloseInputStream(pfd).bufferedReader().use { it.readText() }
                        } else ""
                    } catch (e: Exception) {
                        ""
                    }
                }
                
                val exitCode = remoteProcess.waitFor()
                val stdout = outDeferred.await()
                val stderr = errDeferred.await()
                
                Triple(exitCode, stdout, stderr)
            }

            val (exitCode, stdout, stderr) = outputText

            if (exitCode == 0) {
                ShizukuResult.Success(stdout.trim())
            } else {
                val combinedErr = if (stderr.isNotBlank()) stderr.trim() else "Process exited with code $exitCode"
                ShizukuResult.Error(combinedErr, exitCode)
            }
        } catch (e: Exception) {
            ShizukuResult.Error(e.message ?: "Execution error occurred")
        }
    }
}
