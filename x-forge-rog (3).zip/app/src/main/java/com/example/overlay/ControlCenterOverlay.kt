package com.example.overlay

import android.content.Context
import android.content.Intent
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.MainActivity
import com.example.booster.BoosterManager
import com.example.data.CrosshairProfile
import com.example.ui.theme.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Composable
fun ControlCenterOverlay(
    context: Context,
    boosterManager: BoosterManager,
    onSaveProfile: (CrosshairProfile) -> Unit
) {
    val isPanelOpen by OverlayManager.isPanelOpen.collectAsState()
    val handleSide by OverlayManager.handleSide.collectAsState()
    val handleY by OverlayManager.handleY.collectAsState()
    val currentProfileOpt by OverlayManager.currentProfile.collectAsState()
    
    val currentProfile = currentProfileOpt ?: CrosshairProfile(name = "CLASSIC_X", size = 24f, thickness = 2f, opacity = 0.85f, gap = 0f)

    // Booster stats
    val ramUsage by boosterManager.ramUsage.collectAsState()
    val isBoosting by boosterManager.isBoosting.collectAsState()
    val boostProgress by boosterManager.boostProgress.collectAsState()

    // Screen height helper for drag calculations
    val displayMetrics = context.resources.displayMetrics
    val screenHeightPx = displayMetrics.heightPixels.toFloat()

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = if (handleSide == "LEFT") Alignment.TopStart else Alignment.TopEnd
    ) {
        if (!isPanelOpen) {
            // 1. FLOATING HANDLE
            Box(
                modifier = Modifier
                    .offset(
                        y = ((screenHeightPx * handleY) / displayMetrics.density).dp
                    )
                    .width(42.dp)
                    .height(80.dp)
                    .clip(
                        if (handleSide == "LEFT") RoundedCornerShape(topEnd = 16.dp, bottomEnd = 16.dp)
                        else RoundedCornerShape(topStart = 16.dp, bottomStart = 16.dp)
                    )
                    .background(
                        Brush.horizontalGradient(
                            if (handleSide == "LEFT") listOf(RogSurface, RogSurface.copy(alpha = 0.9f))
                            else listOf(RogSurface.copy(alpha = 0.9f), RogSurface)
                        )
                    )
                    .border(
                        width = 1.dp,
                        brush = Brush.horizontalGradient(
                            if (handleSide == "LEFT") listOf(RogRed, Color.Transparent)
                            else listOf(Color.Transparent, RogRed)
                        ),
                        shape = if (handleSide == "LEFT") RoundedCornerShape(topEnd = 16.dp, bottomEnd = 16.dp)
                        else RoundedCornerShape(topStart = 16.dp, bottomStart = 16.dp)
                    )
                    .pointerInput(Unit) {
                        detectDragGestures(
                            onDrag = { change, dragAmount ->
                                change.consume()
                                val currentYPx = (screenHeightPx * OverlayManager.handleY.value) + dragAmount.y
                                val newYPercent = currentYPx / screenHeightPx
                                OverlayManager.setHandleY(newYPercent)
                            },
                            onDragEnd = {}
                        )
                    }
                    .clickable {
                        OverlayManager.setPanelOpen(true)
                    },
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxSize()
                ) {
                    Icon(
                        imageVector = if (handleSide == "LEFT") Icons.Default.KeyboardArrowRight else Icons.Default.KeyboardArrowLeft,
                        contentDescription = "Open Panel",
                        tint = RogRed,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "ROG",
                        color = RogWhite,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.SansSerif,
                        fontStyle = FontStyle.Italic
                    )
                }
            }
        } else {
            // 2. SLIDING CONTROL PANEL
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.horizontalGradient(
                            if (handleSide == "LEFT") listOf(RogBgDark.copy(alpha = 0.95f), RogSurface.copy(alpha = 0.98f))
                            else listOf(RogSurface.copy(alpha = 0.98f), RogBgDark.copy(alpha = 0.95f))
                        )
                    )
                    .border(
                        width = 1.dp,
                        color = RogRed.copy(alpha = 0.3f)
                    )
                    .verticalScroll(rememberScrollState())
                    .padding(14.dp)
            ) {
                // PANEL HEADER
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(RogRed)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "X-FORGE CENTER",
                            color = RogWhite,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black,
                            fontStyle = FontStyle.Italic,
                            fontFamily = FontFamily.SansSerif
                        )
                    }

                    IconButton(
                        onClick = { OverlayManager.setPanelOpen(false) },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = RogRed,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                Divider(color = RogRed.copy(alpha = 0.2f), thickness = 1.dp, modifier = Modifier.padding(vertical = 10.dp))

                // SECTION 1: CROSSHAIR CONTROL
                Text(
                    text = "🎯 CROSSHAIR",
                    color = RogRed,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                // Current Shape Info
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "Style", color = RogTextSecondary, fontSize = 11.sp)
                    Text(
                        text = currentProfile.shape,
                        color = RogCyan,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))

                // Shape Select Chips
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    val shapes = listOf("CLASSIC_X", "DOT", "SQUARE", "CIRCLE")
                    shapes.forEach { shape ->
                        val isSelected = currentProfile.shape == shape
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(28.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(
                                    if (isSelected) RogRed.copy(alpha = 0.2f)
                                    else Color.White.copy(alpha = 0.04f)
                                )
                                .border(
                                    width = 1.dp,
                                    color = if (isSelected) RogRed.copy(alpha = 0.6f) else Color.Transparent,
                                    shape = RoundedCornerShape(6.dp)
                                )
                                .clickable {
                                    val updated = currentProfile.copy(shape = shape)
                                    OverlayManager.updateProfile(updated)
                                    onSaveProfile(updated)
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = when(shape) {
                                    "CLASSIC_X" -> "Cross"
                                    "DOT" -> "Dot"
                                    "SQUARE" -> "Sq"
                                    "CIRCLE" -> "Circ"
                                    else -> shape
                                },
                                color = if (isSelected) RogRed else RogTextSecondary,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Size Slider
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "Size", color = RogTextSecondary, fontSize = 11.sp)
                    Text(text = "${currentProfile.size.toInt()} px", color = RogWhite, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                }
                Slider(
                    value = currentProfile.size,
                    onValueChange = {
                        val updated = currentProfile.copy(size = it)
                        OverlayManager.updateProfile(updated)
                        onSaveProfile(updated)
                    },
                    valueRange = 8f..120f,
                    colors = SliderDefaults.colors(
                        activeTrackColor = RogRed,
                        inactiveTrackColor = Color.White.copy(alpha = 0.1f),
                        thumbColor = RogRed
                    ),
                    modifier = Modifier.height(24.dp)
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Opacity Slider
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "Opacity", color = RogTextSecondary, fontSize = 11.sp)
                    Text(text = "${(currentProfile.opacity * 100).toInt()}%", color = RogWhite, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                }
                Slider(
                    value = currentProfile.opacity,
                    onValueChange = {
                        val updated = currentProfile.copy(opacity = it)
                        OverlayManager.updateProfile(updated)
                        onSaveProfile(updated)
                    },
                    valueRange = 0.1f..1.0f,
                    colors = SliderDefaults.colors(
                        activeTrackColor = RogRed,
                        inactiveTrackColor = Color.White.copy(alpha = 0.1f),
                        thumbColor = RogRed
                    ),
                    modifier = Modifier.height(24.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Color presets row
                Text(text = "Color Preset", color = RogTextSecondary, fontSize = 11.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val colors = listOf(
                        "#EF4444" to RogRed,
                        "#10B981" to RogGreen,
                        "#06B6D4" to RogCyan,
                        "#EAB308" to RogYellow,
                        "#FFFFFF" to RogWhite
                    )
                    colors.forEach { (hex, colorVal) ->
                        val isSelected = currentProfile.colorHex.lowercase() == hex.lowercase()
                        Box(
                            modifier = Modifier
                                .size(22.dp)
                                .clip(CircleShape)
                                .background(colorVal)
                                .border(
                                    width = 2.dp,
                                    color = if (isSelected) RogWhite else Color.Transparent,
                                    shape = CircleShape
                                )
                                .clickable {
                                    val updated = currentProfile.copy(colorHex = hex)
                                    OverlayManager.updateProfile(updated)
                                    onSaveProfile(updated)
                                }
                        )
                    }
                }

                Divider(color = RogRed.copy(alpha = 0.1f), thickness = 1.dp, modifier = Modifier.padding(vertical = 12.dp))

                // SECTION 2: RAM BOOSTER
                Text(
                    text = "⚡ PERFORMANCE BOOSTER",
                    color = RogRed,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(6.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = RogSurface.copy(alpha = 0.6f)),
                    border = BorderStroke(1.dp, RogRed.copy(alpha = 0.15f))
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "RAM Usage",
                            color = RogTextSecondary,
                            fontSize = 10.sp
                        )
                        Text(
                            text = ramUsage,
                            color = if (isBoosting) RogGreen else RogWhite,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )

                        if (isBoosting) {
                            LinearProgressIndicator(
                                progress = boostProgress,
                                color = RogGreen,
                                trackColor = Color.White.copy(alpha = 0.1f),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(4.dp)
                                    .clip(RoundedCornerShape(2.dp))
                            )
                        } else {
                            Button(
                                onClick = {
                                    CoroutineScope(Dispatchers.Main).launch {
                                        boosterManager.executeMemoryBoost()
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = RogRed),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(vertical = 4.dp, horizontal = 12.dp),
                                modifier = Modifier.height(28.dp)
                            ) {
                                Text(text = "BOOST", fontSize = 10.sp, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }

                Divider(color = RogRed.copy(alpha = 0.1f), thickness = 1.dp, modifier = Modifier.padding(vertical = 12.dp))

                // SECTION 3: SYSTEM QUICK ACCESS & SIDE OPTIONS
                Text(
                    text = "⚙ PANEL PREFERENCES",
                    color = RogRed,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(6.dp))

                // Handle Side choice
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "Handle Side", color = RogTextSecondary, fontSize = 11.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf("LEFT", "RIGHT").forEach { side ->
                            val isSelected = handleSide == side
                            Box(
                                modifier = Modifier
                                    .height(22.dp)
                                    .width(46.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (isSelected) RogRed else Color.White.copy(alpha = 0.05f))
                                    .clickable { OverlayManager.setHandleSide(side) },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(text = side, color = RogWhite, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Shortcut to MainActivity Settings
                Button(
                    onClick = {
                        val intent = Intent(context, MainActivity::class.java).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                        }
                        context.startActivity(intent)
                        OverlayManager.setPanelOpen(false)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.05f)),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.15f)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth().height(32.dp)
                ) {
                    Row(
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.Settings, contentDescription = "Settings", tint = RogWhite, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "App Settings", color = RogWhite, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Divider(color = RogRed.copy(alpha = 0.1f), thickness = 1.dp, modifier = Modifier.padding(vertical = 12.dp))

                // SECTION 4: MODULAR FUTURE ROADMAP PLACEHOLDER
                Text(
                    text = "🚀 FUTURE TOOLKIT (ROADMAP)",
                    color = RogTextMuted,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(4.dp))

                Column(
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    val roadmapItems = listOf(
                        "FPS Monitor & Telemetry",
                        "CPU & GPU Heat Graph",
                        "Shizuku Toolkit",
                        "Game Engine Profiles"
                    )
                    roadmapItems.forEach { item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.White.copy(alpha = 0.02f), RoundedCornerShape(4.dp))
                                .padding(vertical = 4.dp, horizontal = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(4.dp)
                                    .clip(CircleShape)
                                    .background(RogTextMuted)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = item, color = RogTextMuted, fontSize = 9.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }
        }
    }
}
