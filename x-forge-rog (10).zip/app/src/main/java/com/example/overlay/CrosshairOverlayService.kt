package com.example.overlay

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.NotificationCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.SavedStateRegistryController
import androidx.room.Room
import com.example.MainActivity
import com.example.booster.BoosterManager
import com.example.data.AppDatabase
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.example.ui.components.CrosshairDrawing
import com.example.utils.Constants
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

/**
 * Custom light-weight lifecycle owner to support Jetpack Compose inside Android Services.
 */
class ServiceLifecycleOwner : LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {
    private val lifecycleRegistry = LifecycleRegistry(this)
    private val store = ViewModelStore()
    private val savedStateRegistryController = SavedStateRegistryController.create(this)

    init {
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.currentState = Lifecycle.State.CREATED
    }

    fun handleLifecycleEvent(event: Lifecycle.Event) {
        lifecycleRegistry.handleLifecycleEvent(event)
    }

    override val lifecycle: Lifecycle
        get() = lifecycleRegistry

    override val viewModelStore: ViewModelStore
        get() = store

    override val savedStateRegistry: SavedStateRegistry
        get() = savedStateRegistryController.savedStateRegistry
}

/**
 * Background Service that manages the floating overlay window with custom canvas drawing,
 * as well as the ROG Gaming Control Center side panel.
 */
class CrosshairOverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var composeView: ComposeView? = null
    private var controlCenterView: ComposeView? = null
    private var lifecycleOwner: ServiceLifecycleOwner? = null
    
    private val serviceScope = CoroutineScope(Dispatchers.Main)

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
    }

    private fun getControlCenterLayoutParams(isOpen: Boolean, side: String, yPercent: Float): WindowManager.LayoutParams {
        val displayMetrics = resources.displayMetrics
        val screenWidth = displayMetrics.widthPixels
        val screenHeight = displayMetrics.heightPixels

        return WindowManager.LayoutParams().apply {
            type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
            }
            format = PixelFormat.TRANSLUCENT
            flags = (WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS)
            
            gravity = Gravity.TOP or if (side == "LEFT") Gravity.START else Gravity.END

            if (isOpen) {
                // Panel open: occupies 42% of screen width, full height
                width = (screenWidth * 0.42f).toInt()
                height = WindowManager.LayoutParams.MATCH_PARENT
                x = 0
                y = 0
            } else {
                // Panel closed: small draggable handle size
                width = (48 * displayMetrics.density).toInt()
                height = (100 * displayMetrics.density).toInt()
                x = 0
                y = (screenHeight * yPercent).toInt() - (height / 2)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notificationIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, notificationIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification = NotificationCompat.Builder(this, Constants.OVERLAY_CHANNEL_ID)
            .setContentTitle("X-Forge ROG Active")
            .setContentText("Custom Crosshair Overlay and Gaming Center are active.")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()

        startForeground(Constants.OVERLAY_NOTIFICATION_ID, notification)

        val owner = lifecycleOwner ?: ServiceLifecycleOwner().apply {
            handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
            handleLifecycleEvent(Lifecycle.Event.ON_START)
            handleLifecycleEvent(Lifecycle.Event.ON_RESUME)
        }
        lifecycleOwner = owner

        // 1. Crosshair Center Drawing
        if (composeView == null) {
            composeView = ComposeView(this).apply {
                setViewTreeLifecycleOwner(owner)
                setViewTreeViewModelStoreOwner(owner)
                setViewTreeSavedStateRegistryOwner(owner)
                setContent {
                    val profile by OverlayManager.currentProfile.collectAsState()
                    profile?.let { prof ->
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            CrosshairDrawing(profile = prof)
                        }
                    }
                }
            }

            val layoutParams = WindowManager.LayoutParams().apply {
                width = WindowManager.LayoutParams.MATCH_PARENT
                height = WindowManager.LayoutParams.MATCH_PARENT
                type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                } else {
                    @Suppress("DEPRECATION")
                    WindowManager.LayoutParams.TYPE_PHONE
                }
                this.flags = (WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN)
                format = PixelFormat.TRANSLUCENT
                gravity = Gravity.CENTER
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                }
            }

            try {
                windowManager?.addView(composeView, layoutParams)
                OverlayManager.setOverlayActive(true)
            } catch (e: Exception) {
                e.printStackTrace()
                stopSelf()
            }
        }

        // 2. Control Center Side Drawer / Handle
        if (controlCenterView == null) {
            val booster = BoosterManager(applicationContext)
            val db = Room.databaseBuilder(applicationContext, AppDatabase::class.java, "xforge_rog.db").build()
            val dao = db.crosshairDao()

            controlCenterView = ComposeView(this).apply {
                setViewTreeLifecycleOwner(owner)
                setViewTreeViewModelStoreOwner(owner)
                setViewTreeSavedStateRegistryOwner(owner)
                setContent {
                    ControlCenterOverlay(
                        context = this@CrosshairOverlayService,
                        boosterManager = booster,
                        onSaveProfile = { profile ->
                            serviceScope.launch(Dispatchers.IO) {
                                try {
                                    dao.insertProfile(profile)
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                }
                            }
                        }
                    )
                }
            }

            val initialParams = getControlCenterLayoutParams(
                isOpen = OverlayManager.isPanelOpen.value,
                side = OverlayManager.handleSide.value,
                yPercent = OverlayManager.handleY.value
            )

            try {
                windowManager?.addView(controlCenterView, initialParams)
            } catch (e: Exception) {
                e.printStackTrace()
            }

            serviceScope.launch {
                combine(
                    OverlayManager.isPanelOpen,
                    OverlayManager.handleSide,
                    OverlayManager.handleY
                ) { isOpen, side, yPercent ->
                    Triple(isOpen, side, yPercent)
                }.collectLatest { (isOpen, side, yPercent) ->
                    val updatedParams = getControlCenterLayoutParams(isOpen, side, yPercent)
                    try {
                        controlCenterView?.let { view ->
                            windowManager?.updateViewLayout(view, updatedParams)
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }
        }

        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        lifecycleOwner?.apply {
            handleLifecycleEvent(Lifecycle.Event.ON_PAUSE)
            handleLifecycleEvent(Lifecycle.Event.ON_STOP)
            handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        }
        if (composeView != null) {
            try {
                windowManager?.removeView(composeView)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            composeView = null
        }
        if (controlCenterView != null) {
            try {
                windowManager?.removeView(controlCenterView)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            controlCenterView = null
        }
        serviceScope.cancel()
        OverlayManager.setOverlayActive(false)
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val serviceChannel = NotificationChannel(
                Constants.OVERLAY_CHANNEL_ID,
                "X-Forge ROG Service Channel",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(serviceChannel)
        }
    }
}

