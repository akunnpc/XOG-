package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.*
import com.example.viewmodel.XForgeViewModel
import com.example.overlay.OverlayManager

@Composable
fun HomeScreen(
    viewModel: XForgeViewModel,
    onRequestPermission: () -> Unit,
    modifier: Modifier = Modifier
) {
    val fps by viewModel.fps.collectAsStateWithLifecycle()
    val cpuTemp by viewModel.cpuTemp.collectAsStateWithLifecycle()
    val ramUsage by viewModel.ramUsage.collectAsStateWithLifecycle()
    val isBoosting by viewModel.isBoosting.collectAsStateWithLifecycle()
    val boostProgress by viewModel.boostProgress.collectAsStateWithLifecycle()

    val isOverlayActive by OverlayManager.isOverlayActive.collectAsStateWithLifecycle()

    var isShizukuRunning by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        while (true) {
            isShizukuRunning = com.example.shizuku.ShizukuManager.isShizukuRunning()
            kotlinx.coroutines.delay(1500)
        }
    }

    // Pulsing animation for system active dot
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )

    // Rotating rotation for HUD visual
    val rotatingAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "hud_rotation"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(RogBgDark)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // --- System Active Header ---
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(RogRed.copy(alpha = pulseAlpha))
                )
                Text(
                    text = "SYSTEM ACTIVE",
                    color = RogRed,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 2.sp
                )
            }

            // Small badge for Shizuku
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (isShizukuRunning) RogGreen.copy(alpha = 0.1f) else RogRed.copy(alpha = 0.1f))
                    .border(1.dp, if (isShizukuRunning) RogGreen.copy(alpha = 0.3f) else RogRed.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "SHIZUKU: ${if (isShizukuRunning) "ONLINE" else "OFFLINE"}",
                    color = if (isShizukuRunning) RogGreen else RogRed,
                    fontSize = 8.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // --- Holographic HUD Radar Section ---
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.size(240.dp)) {
                val center = androidx.compose.ui.geometry.Offset(size.width / 2, size.height / 2)
                
                // Static outer rings
                drawCircle(
                    color = RogRed.copy(alpha = 0.15f),
                    radius = 110.dp.toPx(),
                    center = center,
                    style = Stroke(width = 1.dp.toPx())
                )
                
                drawCircle(
                    color = RogRed.copy(alpha = 0.05f),
                    radius = 90.dp.toPx(),
                    center = center,
                    style = Stroke(width = 1.5.dp.toPx())
                )

                // Grid axis lines
                drawLine(
                    color = RogRed.copy(alpha = 0.08f),
                    start = androidx.compose.ui.geometry.Offset(0f, center.y),
                    end = androidx.compose.ui.geometry.Offset(size.width, center.y),
                    strokeWidth = 1.dp.toPx()
                )
                drawLine(
                    color = RogRed.copy(alpha = 0.08f),
                    start = androidx.compose.ui.geometry.Offset(center.x, 0f),
                    end = androidx.compose.ui.geometry.Offset(center.x, size.height),
                    strokeWidth = 1.dp.toPx()
                )

                // Dynamic rotating HUD ticks
                drawArc(
                    color = RogRed.copy(alpha = 0.4f),
                    startAngle = rotatingAngle,
                    sweepAngle = 45f,
                    useCenter = false,
                    topLeft = androidx.compose.ui.geometry.Offset(center.x - 100.dp.toPx(), center.y - 100.dp.toPx()),
                    size = androidx.compose.ui.geometry.Size(200.dp.toPx(), 200.dp.toPx()),
                    style = Stroke(width = 2.dp.toPx())
                )

                drawArc(
                    color = RogCyan.copy(alpha = 0.3f),
                    startAngle = rotatingAngle + 180f,
                    sweepAngle = 60f,
                    useCenter = false,
                    topLeft = androidx.compose.ui.geometry.Offset(center.x - 80.dp.toPx(), center.y - 80.dp.toPx()),
                    size = androidx.compose.ui.geometry.Size(160.dp.toPx(), 160.dp.toPx()),
                    style = Stroke(width = 1.dp.toPx())
                )
            }

            // Centered Telemetry Readouts
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = "$fps",
                    color = RogGreen,
                    fontSize = 54.sp,
                    fontWeight = FontWeight.Black,
                    fontStyle = FontStyle.Italic,
                    fontFamily = FontFamily.SansSerif,
                    lineHeight = 54.sp
                )
                Text(
                    text = "FPS METRIC",
                    color = RogTextSecondary,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "$cpuTemp°C",
                            color = RogRed,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "CPU TEMP",
                            color = RogTextMuted,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Box(
                        modifier = Modifier
                            .height(20.dp)
                            .width(1.dp)
                            .background(Color.White.copy(alpha = 0.1f))
                    )
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = ramUsage.split(" / ").firstOrNull() ?: "0GB",
                            color = RogCyan,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "RAM ACTIVE",
                            color = RogTextMuted,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // --- Hardware Boost Subsystem Panel ---
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.02f)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "System RAM Booster",
                        color = RogWhite,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Total System: $ramUsage",
                        color = RogTextSecondary,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )

                    AnimatedVisibility(visible = isBoosting) {
                        Column(modifier = Modifier.padding(top = 8.dp)) {
                            Text(
                                text = "Optimizing JVM Memory...",
                                color = RogRed,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            LinearProgressIndicator(
                                progress = { boostProgress },
                                color = RogRed,
                                trackColor = Color.White.copy(alpha = 0.05f),
                                modifier = Modifier
                                    .width(120.dp)
                                    .height(4.dp)
                            )
                        }
                    }
                }

                Button(
                    onClick = { viewModel.triggerMemoryBoost() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isBoosting) Color.Gray else RogRed.copy(alpha = 0.15f),
                        contentColor = if (isBoosting) Color.DarkGray else RogRed
                    ),
                    border = BorderStroke(1.dp, if (isBoosting) Color.Transparent else RogRed.copy(alpha = 0.4f)),
                    shape = RoundedCornerShape(8.dp),
                    enabled = !isBoosting,
                    modifier = Modifier
                        .height(36.dp)
                        .testTag("boost_memory_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Boost",
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isBoosting) "BOOSTING" else "BOOST",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }

        // --- Bottom Screen Action Floating Overlay Toggler ---
        Button(
            onClick = onRequestPermission,
            colors = ButtonDefaults.buttonColors(
                containerColor = if (isOverlayActive) RogRedDark else RogRed
            ),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("toggle_overlay_button")
        ) {
            Icon(
                imageVector = Icons.Default.PlayArrow,
                contentDescription = "Toggle Service",
                modifier = Modifier.size(16.dp),
                tint = RogWhite
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (isOverlayActive) "STOP OVERLAY SERVICE" else "ACTIVATE FLOATING OVERLAY",
                color = RogWhite,
                fontSize = 13.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp
            )
        }
    }
}
