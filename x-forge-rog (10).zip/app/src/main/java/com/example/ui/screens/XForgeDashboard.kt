package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.*
import com.example.viewmodel.XForgeViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun XForgeDashboard(
    viewModel: XForgeViewModel,
    modifier: Modifier = Modifier,
    onRequestPermission: () -> Unit
) {
    var currentTab by remember { mutableIntStateOf(0) }

    // Telemetry updates
    val fps by viewModel.fps.collectAsStateWithLifecycle()
    val cpuTemp by viewModel.cpuTemp.collectAsStateWithLifecycle()

    // Shared console execution state for seamless interaction
    var consoleTitle by remember { mutableStateOf("User ID Query") }
    var consoleCommand by remember { mutableStateOf("id") }
    var consoleOutput by remember { mutableStateOf("Ready to receive elevated ADB shell instructions. Click any preset query in the Engine tab or enter a custom script.") }
    var isConsoleRunning by remember { mutableStateOf(false) }
    var isConsoleError by remember { mutableStateOf(false) }

    val coroutineScope = rememberCoroutineScope()

    // Centralised command executor shared across tabs
    val executeShellQuery: (String, String) -> Unit = { title, cmd ->
        consoleTitle = title
        consoleCommand = cmd
        consoleOutput = "Running remote process...\n$ $cmd"
        isConsoleRunning = true
        isConsoleError = false
        currentTab = 3 // Switch directly to Console tab

        coroutineScope.launch {
            when (val result = com.example.shizuku.ShizukuManager.executeCommand(cmd)) {
                is com.example.shizuku.ShizukuResult.Success -> {
                    consoleOutput = result.output.ifEmpty { "[Command completed with exit code 0, returned no output]" }
                    isConsoleError = false
                }
                is com.example.shizuku.ShizukuResult.Error -> {
                    consoleOutput = result.message
                    isConsoleError = true
                }
            }
            isConsoleRunning = false
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = RogBgDark,
        topBar = {
            // --- Unified Cyberpunk ROG Header ---
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(RogBgDark)
                    .padding(horizontal = 24.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Left Brand Logotype
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "X-FORGE ",
                            color = RogWhite,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black,
                            fontStyle = FontStyle.Italic,
                            fontFamily = FontFamily.SansSerif
                        )
                        Text(
                            text = "ROG",
                            color = RogRed,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black,
                            fontStyle = FontStyle.Italic,
                            fontFamily = FontFamily.SansSerif,
                            modifier = Modifier.drawBehind {
                                drawLine(
                                    color = RogRed,
                                    start = Offset(0f, size.height - 2.dp.toPx()),
                                    end = Offset(size.width, size.height - 2.dp.toPx()),
                                    strokeWidth = 2.dp.toPx()
                                )
                            }
                        )
                    }

                    // Right Live Status Telemetry Indicator
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "CPU $cpuTemp°C",
                            color = RogTextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Box(
                            modifier = Modifier
                                .size(4.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(Color.White.copy(alpha = 0.2f))
                        )
                        Text(
                            text = "$fps FPS",
                            color = RogGreen,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        },
        bottomBar = {
            // --- Premium Material 3 Bottom Navigation bar ---
            NavigationBar(
                containerColor = RogSurface,
                tonalElevation = 8.dp,
                modifier = Modifier
                    .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                    .windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                // Menu 1: Home
                NavigationBarItem(
                    selected = currentTab == 0,
                    onClick = { currentTab = 0 },
                    icon = { Icon(imageVector = Icons.Default.Home, contentDescription = "Home") },
                    label = { Text("Home", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = RogWhite,
                        unselectedIconColor = RogTextSecondary,
                        selectedTextColor = RogRed,
                        unselectedTextColor = RogTextSecondary,
                        indicatorColor = RogRed
                    )
                )

                // Menu 2: Engine
                NavigationBarItem(
                    selected = currentTab == 1,
                    onClick = { currentTab = 1 },
                    icon = { Icon(imageVector = Icons.Default.Build, contentDescription = "Engine") },
                    label = { Text("Engine", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = RogWhite,
                        unselectedIconColor = RogTextSecondary,
                        selectedTextColor = RogRed,
                        unselectedTextColor = RogTextSecondary,
                        indicatorColor = RogRed
                    )
                )

                // Menu 3: Tools
                NavigationBarItem(
                    selected = currentTab == 2,
                    onClick = { currentTab = 2 },
                    icon = { Icon(imageVector = Icons.Default.Menu, contentDescription = "Tools") },
                    label = { Text("Tools", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = RogWhite,
                        unselectedIconColor = RogTextSecondary,
                        selectedTextColor = RogRed,
                        unselectedTextColor = RogTextSecondary,
                        indicatorColor = RogRed
                    )
                )

                // Menu 4: Console
                NavigationBarItem(
                    selected = currentTab == 3,
                    onClick = { currentTab = 3 },
                    icon = { Icon(imageVector = Icons.Default.List, contentDescription = "Console") },
                    label = { Text("Console", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = RogWhite,
                        unselectedIconColor = RogTextSecondary,
                        selectedTextColor = RogRed,
                        unselectedTextColor = RogTextSecondary,
                        indicatorColor = RogRed
                    )
                )

                // Menu 5: Profile
                NavigationBarItem(
                    selected = currentTab == 4,
                    onClick = { currentTab = 4 },
                    icon = { Icon(imageVector = Icons.Default.Person, contentDescription = "Profile") },
                    label = { Text("Profile", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = RogWhite,
                        unselectedIconColor = RogTextSecondary,
                        selectedTextColor = RogRed,
                        unselectedTextColor = RogTextSecondary,
                        indicatorColor = RogRed
                    )
                )
            }
        }
    ) { innerPadding ->
        // --- Smooth Animated Navigation Screen Transition ---
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                0 -> HomeScreen(
                    viewModel = viewModel,
                    onRequestPermission = onRequestPermission
                )
                1 -> EngineScreen(
                    onExecuteCommand = executeShellQuery
                )
                2 -> ToolsScreen(
                    viewModel = viewModel,
                    onExecuteCommand = executeShellQuery
                )
                3 -> ConsoleScreen(
                    title = consoleTitle,
                    command = consoleCommand,
                    output = consoleOutput,
                    isRunning = isConsoleRunning,
                    isError = isConsoleError,
                    onRunAgain = { executeShellQuery(consoleTitle, consoleCommand) }
                )
                4 -> ProfileScreen()
            }
        }
    }
}
