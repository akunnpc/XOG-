package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.CrosshairDrawing
import com.example.ui.theme.*
import com.example.viewmodel.XForgeViewModel

enum class ToolSelection {
    NONE, OVERLAY, APP_MANAGER, APK_INSTALLER, FILE_MANAGER
}

@Composable
fun ToolsScreen(
    viewModel: XForgeViewModel,
    onExecuteCommand: (title: String, command: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentProfile by viewModel.currentProfile.collectAsStateWithLifecycle()
    val savedProfiles by viewModel.savedProfiles.collectAsStateWithLifecycle()

    var activeTool by remember { mutableStateOf(ToolSelection.OVERLAY) }

    var showSaveDialog by remember { mutableStateOf(false) }
    var showProfilesDialog by remember { mutableStateOf(false) }
    var newProfileName by remember { mutableStateOf("") }

    // State for mock / custom shell app utility
    var targetPackage by remember { mutableStateOf("com.android.chrome") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(RogBgDark)
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- Tab Selection header for utilities ---
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { activeTool = ToolSelection.OVERLAY },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (activeTool == ToolSelection.OVERLAY) RogRed else Color.White.copy(alpha = 0.04f),
                    contentColor = if (activeTool == ToolSelection.OVERLAY) RogWhite else RogTextSecondary
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f).height(40.dp)
            ) {
                Text("Overlay", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = { activeTool = ToolSelection.APP_MANAGER },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (activeTool == ToolSelection.APP_MANAGER) RogRed else Color.White.copy(alpha = 0.04f),
                    contentColor = if (activeTool == ToolSelection.APP_MANAGER) RogWhite else RogTextSecondary
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f).height(40.dp)
            ) {
                Text("App Ops", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = { activeTool = ToolSelection.APK_INSTALLER },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (activeTool == ToolSelection.APK_INSTALLER) RogRed else Color.White.copy(alpha = 0.04f),
                    contentColor = if (activeTool == ToolSelection.APK_INSTALLER) RogWhite else RogTextSecondary
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f).height(40.dp)
            ) {
                Text("Other Utilities", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        // --- Active Tool Body View ---
        when (activeTool) {
            ToolSelection.OVERLAY -> {
                // Interactive crosshair visual designer (preserved with 100% features)
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // --- 1. Preview canvas board ---
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(RogSurface.copy(alpha = 0.4f))
                            .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(16.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val center = Offset(size.width / 2, size.height / 2)
                            // Radar rings
                            drawCircle(
                                color = RogRed.copy(alpha = 0.06f),
                                radius = 60.dp.toPx(),
                                center = center,
                                style = Stroke(width = 1.dp.toPx())
                            )
                            drawCircle(
                                color = RogRed.copy(alpha = 0.02f),
                                radius = 100.dp.toPx(),
                                center = center,
                                style = Stroke(width = 1.dp.toPx())
                            )
                        }

                        Box(
                            modifier = Modifier
                                .size(140.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(RogBgDark.copy(alpha = 0.7f))
                                .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(16.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .drawBehind {
                                        val step = 14.dp.toPx()
                                        var x = step
                                        while (x < size.width) {
                                            drawLine(
                                                color = Color.White.copy(alpha = 0.02f),
                                                start = Offset(x, 0f),
                                                end = Offset(x, size.height),
                                                strokeWidth = 0.5.dp.toPx()
                                            )
                                            x += step
                                        }
                                        var y = step
                                        while (y < size.height) {
                                            drawLine(
                                                color = Color.White.copy(alpha = 0.02f),
                                                start = Offset(0f, y),
                                                end = Offset(size.width, y),
                                                strokeWidth = 0.5.dp.toPx()
                                            )
                                            y += step
                                        }
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                CrosshairDrawing(profile = currentProfile)
                            }
                        }
                    }

                    // --- 2. Configuration Options Scroll Column ---
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = RogSurface),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            // Profiles Row
                            item {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text("Parameters Designer", color = RogWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                        Text("Current: ${currentProfile.name}", color = RogTextSecondary, fontSize = 10.sp)
                                    }

                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        IconButton(
                                            onClick = { showProfilesDialog = true },
                                            modifier = Modifier
                                                .size(32.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(Color.White.copy(alpha = 0.05f))
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.List,
                                                contentDescription = "Profiles",
                                                tint = RogWhite,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }

                                        Button(
                                            onClick = {
                                                newProfileName = ""
                                                showSaveDialog = true
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = RogRed),
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 8.dp),
                                            modifier = Modifier.height(32.dp).testTag("save_profile_button")
                                        ) {
                                            Text("SAVE", fontSize = 9.sp, fontWeight = FontWeight.Black)
                                        }
                                    }
                                }
                            }

                            // Shape Selector
                            item {
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text("Shape Style", color = RogTextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        val shapes = listOf("CLASSIC_X" to "Cross", "DOT" to "Dot", "SQUARE" to "Square", "CIRCLE" to "Circle")
                                        shapes.forEach { (type, label) ->
                                            val selected = currentProfile.shape == type
                                            Box(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .height(36.dp)
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .background(if (selected) RogRed.copy(alpha = 0.15f) else Color.White.copy(alpha = 0.04f))
                                                    .border(1.dp, if (selected) RogRed.copy(alpha = 0.4f) else Color.Transparent, RoundedCornerShape(8.dp))
                                                    .clickable { viewModel.updateShape(type) }
                                                    .testTag("shape_${type.lowercase()}_button"),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(label, color = if (selected) RogRed else RogTextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }

                            // Sliders: Size, Thickness, Clearance Gap, Opacity
                            item {
                                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    // Size
                                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("Size", color = RogTextSecondary, fontSize = 11.sp)
                                            Text("${currentProfile.size.toInt()} px", color = RogWhite, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                        }
                                        Slider(
                                            value = currentProfile.size,
                                            onValueChange = { viewModel.updateSize(it) },
                                            valueRange = 10f..120f,
                                            colors = SliderDefaults.colors(thumbColor = RogWhite, activeTrackColor = RogRed),
                                            modifier = Modifier.height(24.dp).testTag("size_slider")
                                        )
                                    }

                                    // Thickness
                                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("Line Thickness", color = RogTextSecondary, fontSize = 11.sp)
                                            Text("${currentProfile.thickness.toInt()} dp", color = RogWhite, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                        }
                                        Slider(
                                            value = currentProfile.thickness,
                                            onValueChange = { viewModel.updateThickness(it) },
                                            valueRange = 1f..12f,
                                            colors = SliderDefaults.colors(thumbColor = RogWhite, activeTrackColor = RogRed),
                                            modifier = Modifier.height(24.dp).testTag("weight_slider")
                                        )
                                    }

                                    // Clearance Gap
                                    if (currentProfile.shape != "DOT") {
                                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                Text("Inner clearance (Gap)", color = RogTextSecondary, fontSize = 11.sp)
                                                Text("${currentProfile.gap.toInt()} px", color = RogWhite, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                            }
                                            Slider(
                                                value = currentProfile.gap,
                                                onValueChange = { viewModel.updateGap(it) },
                                                valueRange = 0f..30f,
                                                colors = SliderDefaults.colors(thumbColor = RogWhite, activeTrackColor = RogRed),
                                                modifier = Modifier.height(24.dp).testTag("gap_slider")
                                            )
                                        }
                                    }

                                    // Opacity
                                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("Opacity Alpha", color = RogTextSecondary, fontSize = 11.sp)
                                            Text("${(currentProfile.opacity * 100).toInt()}%", color = RogWhite, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                        }
                                        Slider(
                                            value = currentProfile.opacity,
                                            onValueChange = { viewModel.updateOpacity(it) },
                                            valueRange = 0.1f..1.0f,
                                            colors = SliderDefaults.colors(thumbColor = RogWhite, activeTrackColor = RogRed),
                                            modifier = Modifier.height(24.dp).testTag("opacity_slider")
                                        )
                                    }
                                }
                            }

                            // Accent Colors
                            item {
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text("Color Accents", color = RogTextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    val colors = listOf(
                                        "#EF4444" to RogRed, "#10B981" to RogGreen, "#06B6D4" to RogCyan,
                                        "#EAB308" to RogYellow, "#3B82F6" to RogBlue, "#FFFFFF" to RogWhite
                                    )
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        colors.forEach { (hex, composeColor) ->
                                            val selected = currentProfile.colorHex.equals(hex, ignoreCase = true)
                                            Box(
                                                modifier = Modifier
                                                    .size(36.dp)
                                                    .clip(CircleShape)
                                                    .background(composeColor)
                                                    .border(
                                                        width = if (selected) 3.dp else 1.dp,
                                                        color = if (selected) RogWhite else Color.White.copy(alpha = 0.15f),
                                                        shape = CircleShape
                                                    )
                                                    .clickable { viewModel.updateColor(hex) }
                                                    .testTag("color_${hex.replace("#", "")}_button"),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                if (selected) {
                                                    Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(RogBgDark))
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            ToolSelection.APP_MANAGER -> {
                // Real Elevated App Operations using Shizuku commands
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = RogSurface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(
                            text = "Elevated App Operations",
                            color = RogWhite,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Control any installed package using elevated Shizuku ADB shell interfaces. Operations are securely applied to user applications.",
                            color = RogTextSecondary,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )

                        // Package Name Target input
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Target Package ID", color = RogTextSecondary, fontSize = 11.sp)
                            TextField(
                                value = targetPackage,
                                onValueChange = { targetPackage = it },
                                colors = TextFieldDefaults.colors(
                                    focusedTextColor = RogWhite,
                                    unfocusedTextColor = RogWhite,
                                    focusedContainerColor = RogBgDark,
                                    unfocusedContainerColor = RogBgDark,
                                    focusedIndicatorColor = RogRed,
                                    unfocusedIndicatorColor = Color.Transparent
                                ),
                                shape = RoundedCornerShape(8.dp),
                                textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace, fontSize = 12.sp),
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                        }

                        // Presets Row
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Presets Shortcuts", color = RogTextSecondary, fontSize = 10.sp)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                val packagePresets = listOf(
                                    "Chrome" to "com.android.chrome",
                                    "YouTube" to "com.google.android.youtube",
                                    "System UI" to "com.android.systemui"
                                )
                                packagePresets.forEach { (label, pkg) ->
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(32.dp)
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(Color.White.copy(alpha = 0.04f))
                                            .clickable { targetPackage = pkg },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(label, color = RogRed, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.weight(1f))

                        // Operations Grid
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                // Force Stop Button
                                Button(
                                    onClick = {
                                        onExecuteCommand("Force Stop App", "am force-stop $targetPackage")
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = RogRed.copy(alpha = 0.15f), contentColor = RogRed),
                                    border = BorderStroke(1.dp, RogRed.copy(alpha = 0.4f)),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f).height(44.dp)
                                ) {
                                    Text("FORCE STOP", fontSize = 10.sp, fontWeight = FontWeight.Black)
                                }

                                // Clear Cache Button
                                Button(
                                    onClick = {
                                        onExecuteCommand("Clear Package Cache", "pm clear $targetPackage")
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = RogCyan.copy(alpha = 0.1f), contentColor = RogCyan),
                                    border = BorderStroke(1.dp, RogCyan.copy(alpha = 0.4f)),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f).height(44.dp)
                                ) {
                                    Text("CLEAR DATA", fontSize = 10.sp, fontWeight = FontWeight.Black)
                                }
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                // Launch App Button
                                Button(
                                    onClick = {
                                        onExecuteCommand("Launch Target Package", "monkey -p $targetPackage -c android.intent.category.LAUNCHER 1")
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = RogGreen.copy(alpha = 0.1f), contentColor = RogGreen),
                                    border = BorderStroke(1.dp, RogGreen.copy(alpha = 0.4f)),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f).height(44.dp)
                                ) {
                                    Text("LAUNCH APP", fontSize = 10.sp, fontWeight = FontWeight.Black)
                                }

                                // Query Package Info Button
                                Button(
                                    onClick = {
                                        onExecuteCommand("Package Manifest Information", "dumpsys package $targetPackage | head -n 35")
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.05f), contentColor = RogWhite),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f).height(44.dp)
                                ) {
                                    Text("PACKAGE DUMP", fontSize = 10.sp, fontWeight = FontWeight.Black)
                                }
                            }
                        }
                    }
                }
            }

            ToolSelection.APK_INSTALLER -> {
                // Visual layout for other requested tools: File Manager, APK Installer, Package Manager
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = RogSurface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item {
                            Text("System Utilities Suite", color = RogWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            Text("Mock integration panels. Real Shizuku integration hook triggers available.", color = RogTextSecondary, fontSize = 10.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                        }

                        // APK Installer Card
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth().border(1.dp, Color.White.copy(alpha = 0.04f), RoundedCornerShape(12.dp)),
                                colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.01f)),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Icon(imageVector = Icons.Default.Add, contentDescription = "Installer", tint = RogRed, modifier = Modifier.size(20.dp))
                                        Column {
                                            Text("ADB APK Installer", color = RogWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            Text("Surgically install APK files bypassing verification", color = RogTextSecondary, fontSize = 9.sp)
                                        }
                                    }
                                    Button(
                                        onClick = { Toast.makeText(context, "Locating local APK files in /Download...", Toast.LENGTH_SHORT).show() },
                                        colors = ButtonDefaults.buttonColors(containerColor = RogRed.copy(alpha = 0.15f), contentColor = RogRed),
                                        shape = RoundedCornerShape(6.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp),
                                        modifier = Modifier.height(28.dp)
                                    ) {
                                        Text("SELECT", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }

                        // App Manager / Package Manager
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth().border(1.dp, Color.White.copy(alpha = 0.04f), RoundedCornerShape(12.dp)),
                                colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.01f)),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Icon(imageVector = Icons.Default.List, contentDescription = "Package Manager", tint = RogCyan, modifier = Modifier.size(20.dp))
                                        Column {
                                            Text("Package Inspector Suite", color = RogWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            Text("List, audit, and extract package APK files", color = RogTextSecondary, fontSize = 9.sp)
                                        }
                                    }
                                    Button(
                                        onClick = {
                                            onExecuteCommand("System Installed Packages", "pm list packages -f -3 | head -n 30")
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = RogCyan.copy(alpha = 0.1f), contentColor = RogCyan),
                                        shape = RoundedCornerShape(6.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp),
                                        modifier = Modifier.height(28.dp)
                                    ) {
                                        Text("LIST THIRD PARTY", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }

                        // Elevated File Manager
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth().border(1.dp, Color.White.copy(alpha = 0.04f), RoundedCornerShape(12.dp)),
                                colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.01f)),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Icon(imageVector = Icons.Default.Menu, contentDescription = "File Manager", tint = RogGreen, modifier = Modifier.size(20.dp))
                                        Column {
                                            Text("ADB Shell File Browser", color = RogWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            Text("Explore system directories securely with ADB permission", color = RogTextSecondary, fontSize = 9.sp)
                                        }
                                    }
                                    Button(
                                        onClick = {
                                            onExecuteCommand("ADB Root Directory Listing", "ls -la /sdcard | head -n 30")
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = RogGreen.copy(alpha = 0.1f), contentColor = RogGreen),
                                        shape = RoundedCornerShape(6.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp),
                                        modifier = Modifier.height(28.dp)
                                    ) {
                                        Text("BROWSER /SDCARD", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }

                        // Added space for future expansions
                        item {
                            Spacer(modifier = Modifier.height(10.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(60.dp)
                                    .border(1.dp, Color.White.copy(alpha = 0.03f), RoundedCornerShape(12.dp))
                                    .background(Color.White.copy(alpha = 0.01f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "+ Add Custom Action Script Builder",
                                    color = RogTextMuted,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
            else -> {}
        }
    }

    // --- Save Dialog (Overlay Profile) ---
    if (showSaveDialog) {
        Dialog(onDismissRequest = { showSaveDialog = false }) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(24.dp),
                color = RogSurface,
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f))
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(text = "Save Crosshair Profile", color = RogWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "Store configurations as preset profile", color = RogTextSecondary, fontSize = 10.sp)
                    Spacer(modifier = Modifier.height(16.dp))

                    TextField(
                        value = newProfileName,
                        onValueChange = { newProfileName = it },
                        placeholder = { Text("E.g., Custom Crosshair", color = RogTextMuted, fontSize = 12.sp) },
                        colors = TextFieldDefaults.colors(
                            focusedTextColor = RogWhite,
                            unfocusedTextColor = RogWhite,
                            focusedContainerColor = RogBgDark,
                            unfocusedContainerColor = RogBgDark,
                            focusedIndicatorColor = RogRed,
                            unfocusedIndicatorColor = Color.Transparent
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().testTag("profile_name_input")
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = { showSaveDialog = false },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.05f)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Cancel", color = RogTextSecondary)
                        }

                        Button(
                            onClick = {
                                if (newProfileName.isNotBlank()) {
                                    viewModel.createAndSaveNewProfile(newProfileName.trim())
                                    showSaveDialog = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = RogRed),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f).testTag("dialog_save_confirm")
                        ) {
                            Text("Save", color = RogWhite)
                        }
                    }
                }
            }
        }
    }

    // --- Saved Profiles List Dialog ---
    if (showProfilesDialog) {
        Dialog(onDismissRequest = { showProfilesDialog = false }) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .heightIn(max = 400.dp),
                shape = RoundedCornerShape(24.dp),
                color = RogSurface,
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f))
            ) {
                Column(modifier = Modifier.padding(24.dp)) {
                    Text(text = "Saved Preset Profiles", color = RogWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(16.dp))

                    if (savedProfiles.isEmpty()) {
                        Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Text("No custom profiles found.", color = RogTextMuted, fontSize = 12.sp)
                        }
                    } else {
                        LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(savedProfiles) { profile ->
                                val active = profile.id == currentProfile.id
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (active) RogRed.copy(alpha = 0.08f) else Color.White.copy(alpha = 0.03f))
                                        .border(1.dp, if (active) RogRed.copy(alpha = 0.3f) else Color.Transparent, RoundedCornerShape(10.dp))
                                        .clickable {
                                            viewModel.selectProfile(profile)
                                            showProfilesDialog = false
                                        }
                                        .padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(text = profile.name, color = if (active) RogRed else RogWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(text = "${profile.shape} | Size ${profile.size.toInt()}px", color = RogTextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                    }

                                    IconButton(
                                        onClick = { viewModel.deleteProfile(profile) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = RogTextMuted, modifier = Modifier.size(14.dp))
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { showProfilesDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.05f)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Close", color = RogTextSecondary)
                    }
                }
            }
        }
    }
}
