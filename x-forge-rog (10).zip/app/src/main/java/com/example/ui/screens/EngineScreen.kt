package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.*

data class QueryItem(
    val title: String,
    val command: String,
    val icon: ImageVector,
    val description: String
)

@Composable
fun EngineScreen(
    onExecuteCommand: (title: String, command: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var isShizukuRunning by remember { mutableStateOf(false) }
    var hasShizukuPermission by remember { mutableStateOf(false) }
    var isShizukuInstalled by remember { mutableStateOf(false) }
    var showInstallDialog by remember { mutableStateOf(false) }
    var manualCommand by remember { mutableStateOf("") }

    // Periodic check to update status dynamically
    LaunchedEffect(Unit) {
        while (true) {
            isShizukuRunning = com.example.shizuku.ShizukuManager.isShizukuRunning()
            hasShizukuPermission = com.example.shizuku.ShizukuManager.hasPermission()
            isShizukuInstalled = com.example.shizuku.ShizukuManager.isShizukuInstalled(context)
            kotlinx.coroutines.delay(1500)
        }
    }

    val queriesList = remember {
        listOf(
            QueryItem("User ID", "id", Icons.Default.Person, "Check current Linux UID context"),
            QueryItem("Device Model", "getprop ro.product.model", Icons.Default.Build, "Get hardware model signature"),
            QueryItem("Android Version", "getprop ro.build.version.release", Icons.Default.Info, "Query target system API level"),
            QueryItem("CPU ABI", "getprop ro.product.cpu.abi", Icons.Default.Star, "Retrieve processor architecture"),
            QueryItem("RAM Info", "cat /proc/meminfo | head -n 4", Icons.Default.Refresh, "Query memory parameters"),
            QueryItem("Storage", "df -h /data", Icons.Default.Menu, "Inspect system storage block"),
            QueryItem("Battery Status", "dumpsys battery | head -n 12", Icons.Default.Warning, "Fetch hardware battery metrics"),
            QueryItem("Packages Summary", "pm list packages | head -n 20", Icons.Default.List, "Query installed packages preview"),
            QueryItem("Build Signature", "getprop ro.build.fingerprint", Icons.Default.Lock, "Inspect build finger fingerprint")
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(RogBgDark)
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- Shizuku Control Header Card ---
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(16.dp))
                .testTag("shizuku_card"),
            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.02f)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Build,
                            contentDescription = "Shizuku Engine",
                            tint = RogRed,
                            modifier = Modifier.size(20.dp)
                        )
                        Column {
                            Text(
                                text = "Shizuku Core Engine",
                                color = RogWhite,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "API-based Shell Bridge",
                                color = RogTextMuted,
                                fontSize = 10.sp
                            )
                        }
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(if (isShizukuRunning) RogGreen else RogRed)
                        )
                        Text(
                            text = if (isShizukuRunning) "RUNNING" else "STOPPED",
                            color = if (isShizukuRunning) RogGreen else RogRed,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                HorizontalDivider(color = Color.White.copy(alpha = 0.05f))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Permission Status",
                        color = RogTextSecondary,
                        fontSize = 11.sp
                    )
                    Text(
                        text = if (hasShizukuPermission) "GRANTED" else "NOT GRANTED",
                        color = if (hasShizukuPermission) RogGreen else RogYellow,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            android.util.Log.d("ShizukuTrace", "[Connect Button Click] onClick listener executed")
                            android.util.Log.d("ShizukuTrace", "[Connect Button Click] isShizukuInstalled = $isShizukuInstalled")
                            android.util.Log.d("ShizukuTrace", "[Connect Button Click] Does it call ShizukuManager.init()? No, not in Connect button.")
                            android.util.Log.d("ShizukuTrace", "[Connect Button Click] Does it call requestPermission()? No, not in Connect button.")

                            if (isShizukuInstalled) {
                                val intent = com.example.shizuku.ShizukuManager.getLaunchShizukuIntent(context)
                                if (intent != null) {
                                    context.startActivity(intent)
                                } else {
                                    Toast.makeText(context, "Cannot launch Shizuku App.", Toast.LENGTH_SHORT).show()
                                }
                            } else {
                                showInstallDialog = true
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.White.copy(alpha = 0.05f),
                            contentColor = RogWhite
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(36.dp)
                            .testTag("connect_shizuku_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "Connect",
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Connect", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            if (!isShizukuRunning) {
                                Toast.makeText(context, "Please start Shizuku service first.", Toast.LENGTH_SHORT).show()
                            } else {
                                com.example.shizuku.ShizukuManager.requestPermission()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isShizukuRunning && !hasShizukuPermission) RogRed else Color.White.copy(alpha = 0.05f),
                            contentColor = if (isShizukuRunning && !hasShizukuPermission) RogWhite else RogTextSecondary
                        ),
                        shape = RoundedCornerShape(8.dp),
                        enabled = isShizukuRunning && !hasShizukuPermission,
                        modifier = Modifier
                            .weight(1f)
                            .height(36.dp)
                            .testTag("grant_shizuku_permission_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Grant",
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Grant Access", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // --- Custom Manual Command Entry Bar ---
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TextField(
                value = manualCommand,
                onValueChange = { manualCommand = it },
                placeholder = { Text("Enter custom elevated shell command...", color = RogTextMuted, fontSize = 11.sp) },
                colors = TextFieldDefaults.colors(
                    focusedTextColor = RogWhite,
                    unfocusedTextColor = RogWhite,
                    focusedContainerColor = RogSurface,
                    unfocusedContainerColor = RogSurface,
                    focusedIndicatorColor = RogRed,
                    unfocusedIndicatorColor = Color.Transparent
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp)
                    .testTag("shizuku_command_input"),
                textStyle = LocalTextStyle.current.copy(fontSize = 11.sp, fontFamily = FontFamily.Monospace),
                singleLine = true
            )

            Button(
                onClick = {
                    if (manualCommand.isNotBlank()) {
                        onExecuteCommand("Manual Input", manualCommand.trim())
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = RogRed),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 12.dp),
                modifier = Modifier
                    .height(44.dp)
                    .testTag("run_command_button"),
                enabled = manualCommand.isNotBlank()
            ) {
                Text("RUN", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        // --- System Queries Title ---
        Text(
            text = "Elevated System Queries",
            color = RogWhite,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 4.dp)
        )

        // --- Grid of Preset Queries ---
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.weight(1f),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(queriesList) { item ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp)
                        .border(1.dp, Color.White.copy(alpha = 0.04f), RoundedCornerShape(12.dp))
                        .clickable { onExecuteCommand(item.title, item.command) }
                        .testTag("preset_${item.command.replace(" ", "_")}"),
                    colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.02f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = item.icon,
                                contentDescription = item.title,
                                tint = RogRed,
                                modifier = Modifier.size(18.dp)
                            )
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Run",
                                tint = RogTextMuted,
                                modifier = Modifier.size(12.dp)
                            )
                        }

                        Column {
                            Text(
                                text = item.title,
                                color = RogWhite,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = item.description,
                                color = RogTextSecondary,
                                fontSize = 9.sp,
                                lineHeight = 11.sp
                            )
                        }
                    }
                }
            }
        }
    }

    // --- Install Dialog ---
    if (showInstallDialog) {
        Dialog(onDismissRequest = { showInstallDialog = false }) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(20.dp),
                color = RogSurface,
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f))
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Not Found",
                        tint = RogYellow,
                        modifier = Modifier.size(36.dp)
                    )
                    Text(
                        text = "Shizuku Manager Not Found",
                        color = RogWhite,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "Shizuku allows user-space applications to execute elevated ADB system commands securely. To use this foundation, please install Shizuku from the Google Play Store, start the Shizuku service via ADB, and then connect to it here.",
                        color = RogTextSecondary,
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center,
                        lineHeight = 15.sp
                    )
                    Button(
                        onClick = { showInstallDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = RogRed),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Acknowledge", color = RogWhite, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}
