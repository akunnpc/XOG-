package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun ProfileScreen(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    var activeTheme by remember { mutableStateOf("ROG Crimson") }
    var activeAccentColor by remember { mutableStateOf("#EF4444") }

    var aggressivePurge by remember { mutableStateOf(true) }
    var detailDebug by remember { mutableStateOf(false) }
    var fpsLock by remember { mutableStateOf(true) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(RogBgDark)
            .verticalScroll(scrollState)
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // --- Admin Profile Header Card ---
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = RogSurface),
            shape = RoundedCornerShape(16.dp)
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Glow Avatar Frame
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(RogRed.copy(alpha = 0.1f))
                        .border(2.dp, RogRed, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = "User Avatar",
                        tint = RogRed,
                        modifier = Modifier.size(28.dp)
                    )
                }

                Column {
                    Text(
                        text = "FORGER_OPERATOR",
                        color = RogWhite,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(RogGreen)
                        )
                        Text(
                            text = "SECURE LOCAL DEV CONSOLE",
                            color = RogGreen,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        // --- Category: Personalization ---
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = "VISUAL PERSONALIZATION",
                color = RogTextMuted,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color.White.copy(alpha = 0.03f), RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.01f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Active Theme Selection
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Interactive Gaming Themes", color = RogTextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            val themes = listOf("ROG Crimson", "Cyber Neon", "Abyssal Slate")
                            themes.forEach { t ->
                                val selected = activeTheme == t
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(34.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (selected) RogRed.copy(alpha = 0.15f) else Color.White.copy(alpha = 0.03f))
                                        .border(1.dp, if (selected) RogRed.copy(alpha = 0.4f) else Color.Transparent, RoundedCornerShape(8.dp))
                                        .clickable {
                                            activeTheme = t
                                            Toast.makeText(context, "Theme set to $t", Toast.LENGTH_SHORT).show()
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = t.split(" ").last(),
                                        color = if (selected) RogRed else RogTextSecondary,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    HorizontalDivider(color = Color.White.copy(alpha = 0.05f))

                    // Custom Accent Dot Pickers
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("System Accent Highlight", color = RogTextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            val accents = listOf(
                                "#EF4444" to RogRed,
                                "#10B981" to RogGreen,
                                "#06B6D4" to RogCyan,
                                "#EAB308" to RogYellow,
                                "#3B82F6" to RogBlue
                            )
                            accents.forEach { (hex, composeColor) ->
                                val selected = activeAccentColor == hex
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(composeColor)
                                        .border(
                                            width = if (selected) 3.dp else 1.dp,
                                            color = if (selected) RogWhite else Color.White.copy(alpha = 0.2f),
                                            shape = CircleShape
                                        )
                                        .clickable {
                                            activeAccentColor = hex
                                            Toast.makeText(context, "Accent color applied", Toast.LENGTH_SHORT).show()
                                        }
                                )
                            }
                        }
                    }
                }
            }
        }

        // --- Category: Diagnostics Settings ---
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = "DEVELOPER DIAGNOSTICS",
                color = RogTextMuted,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Toggle 1: Aggressive Purge
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color.White.copy(alpha = 0.03f), RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.01f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Aggressive RAM Purge", color = RogWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text("Purges memory blocks aggressively on boost loops", color = RogTextSecondary, fontSize = 9.sp)
                        }
                        Switch(
                            checked = aggressivePurge,
                            onCheckedChange = { aggressivePurge = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = RogWhite, checkedTrackColor = RogRed)
                        )
                    }
                }

                // Toggle 2: Detailed Debug Logs
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color.White.copy(alpha = 0.03f), RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.01f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Detailed Shizuku Debug Logs", color = RogWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text("Print binder listener and permission lifecycle callbacks to Logcat", color = RogTextSecondary, fontSize = 9.sp)
                        }
                        Switch(
                            checked = detailDebug,
                            onCheckedChange = { detailDebug = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = RogWhite, checkedTrackColor = RogRed)
                        )
                    }
                }

                // Toggle 3: FPS Lock 120Hz
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color.White.copy(alpha = 0.03f), RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.01f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Overlay Frame Rate Lock 120Hz", color = RogWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text("Enforces 120 FPS high-refresh-rate overlay drawing states", color = RogTextSecondary, fontSize = 9.sp)
                        }
                        Switch(
                            checked = fpsLock,
                            onCheckedChange = { fpsLock = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = RogWhite, checkedTrackColor = RogRed)
                        )
                    }
                }
            }
        }

        // --- Category: About Engine ---
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = "ABOUT SYSTEM FORGER",
                color = RogTextMuted,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = RogSurface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Application Name", color = RogTextSecondary, fontSize = 11.sp)
                        Text("X-Forge ROG Engine", color = RogWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Build Version", color = RogTextSecondary, fontSize = 11.sp)
                        Text("v2.1.0-PRO-STABLE", color = RogRed, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Platform Architecture", color = RogTextSecondary, fontSize = 11.sp)
                        Text("ARM64-v8a", color = RogWhite, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Target Framework", color = RogTextSecondary, fontSize = 11.sp)
                        Text("Material 3 | Compose Jetpack", color = RogWhite, fontSize = 11.sp)
                    }

                    HorizontalDivider(color = Color.White.copy(alpha = 0.05f))

                    Text(
                        text = "Designed specifically for extreme mobile users desiring system metric dashboards and granular tactical customizations.",
                        color = RogTextMuted,
                        fontSize = 10.sp,
                        textAlign = TextAlign.Center,
                        lineHeight = 14.sp,
                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                    )
                }
            }
        }
    }
}
