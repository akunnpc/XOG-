package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = RogRed,
    secondary = RogRedDark,
    tertiary = RogCyan,
    background = RogBgDark,
    surface = RogSurface,
    onPrimary = RogWhite,
    onBackground = RogTextPrimary,
    onSurface = RogTextPrimary
  )

private val LightColorScheme = DarkColorScheme // Force dark theme for gaming utility

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true, // Force dark
  dynamicColor: Boolean = false, // Disable dynamic colors to preserve ROG aesthetic
  content: @Composable () -> Unit,
) {
  val colorScheme = DarkColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
