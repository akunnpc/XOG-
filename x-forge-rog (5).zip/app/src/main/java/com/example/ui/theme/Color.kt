package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFEF4444) // Changed to gaming red
val PurpleGrey80 = Color(0xFF16171D) // Dark graphite
val Pink80 = Color(0xFF0A0A0B) // Absolute metallic dark

val Purple40 = Color(0xFFDC2626)
val PurpleGrey40 = Color(0xFF232530)
val Pink40 = Color(0xFF0F1015)

// Theme Specific Palette
val RogRed = Color(0xFFEF4444)
val RogRedDark = Color(0xFFDC2626)
val RogBgDark = Color(0xFF0A0A0B)
val RogSurface = Color(0xFF16171D)
val RogTextPrimary = Color(0xFFF1F5F9)
val RogTextSecondary = Color(0xFF94A3B8)
val RogTextMuted = Color(0xFF64748B)

val RogGreen = Color(0xFF10B981)
val RogCyan = Color(0xFF06B6D4)
val RogYellow = Color(0xFFEAB308)
val RogBlue = Color(0xFF3B82F6)
val RogWhite = Color(0xFFFFFFFF)

