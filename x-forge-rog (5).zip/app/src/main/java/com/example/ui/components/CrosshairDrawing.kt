package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.example.data.CrosshairProfile
import com.example.utils.toComposeColor

/**
 * Custom Canvas Drawing Composable.
 * Draws different styles of crosshairs dynamically based on profile configurations.
 */
@Composable
fun CrosshairDrawing(profile: CrosshairProfile, modifier: Modifier = Modifier) {
    val sizeDp = profile.size.dp
    Box(
        modifier = modifier.size(sizeDp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(sizeDp)) {
            val center = Offset(size.width / 2, size.height / 2)
            val thicknessPx = profile.thickness * density
            val gapPx = profile.gap * density
            val color = profile.colorHex.toComposeColor(profile.opacity)

            when (profile.shape) {
                "CLASSIC_X" -> {
                    val halfLen = size.width / 2
                    // Left line
                    if (halfLen - gapPx > 0) {
                        drawLine(
                            color = color,
                            start = Offset(0f, center.y),
                            end = Offset(halfLen - gapPx, center.y),
                            strokeWidth = thicknessPx
                        )
                    }
                    // Right line
                    if (halfLen + gapPx < size.width) {
                        drawLine(
                            color = color,
                            start = Offset(halfLen + gapPx, center.y),
                            end = Offset(size.width, center.y),
                            strokeWidth = thicknessPx
                        )
                    }
                    // Top line
                    if (halfLen - gapPx > 0) {
                        drawLine(
                            color = color,
                            start = Offset(center.x, 0f),
                            end = Offset(center.x, halfLen - gapPx),
                            strokeWidth = thicknessPx
                        )
                    }
                    // Bottom line
                    if (halfLen + gapPx < size.height) {
                        drawLine(
                            color = color,
                            start = Offset(center.x, halfLen + gapPx),
                            end = Offset(center.x, size.height),
                            strokeWidth = thicknessPx
                        )
                    }
                }
                "DOT" -> {
                    val r = (profile.thickness * density).coerceAtLeast(1.5f * density)
                    drawCircle(
                        color = color,
                        radius = r,
                        center = center
                    )
                }
                "SQUARE" -> {
                    val halfSize = size.width / 4
                    drawRect(
                        color = color,
                        topLeft = Offset(center.x - halfSize, center.y - halfSize),
                        size = Size(halfSize * 2, halfSize * 2),
                        style = Stroke(width = thicknessPx)
                    )
                }
                "CIRCLE" -> {
                    val r = size.width / 3
                    drawCircle(
                        color = color,
                        radius = r,
                        center = center,
                        style = Stroke(width = thicknessPx)
                    )
                    if (gapPx > 0) {
                        drawCircle(
                            color = color,
                            radius = (thicknessPx / 2).coerceAtLeast(1f),
                            center = center
                        )
                    }
                }
            }
        }
    }
}
