package com.example

import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.ui.Modifier
import androidx.lifecycle.ViewModelProvider
import androidx.room.Room
import com.example.data.AppDatabase
import com.example.overlay.OverlayManager
import com.example.permission.PermissionManager
import com.example.ui.screens.XForgeDashboard
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.XForgeViewModel
import com.example.viewmodel.XForgeViewModelFactory

/**
 * Main Activity which serves as the professional application entry point and system
 * permission coordinator.
 */
class MainActivity : ComponentActivity() {

    private lateinit var database: AppDatabase
    private lateinit var viewModel: XForgeViewModel
    private lateinit var permissionManager: PermissionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // 1. Initialize permission helper
        permissionManager = PermissionManager(this)

        // 2. Setup Local Room DB
        database = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "xforge_rog.db"
        ).build()

        // 3. Setup Presentation ViewModel with Factory injection
        val factory = XForgeViewModelFactory(this, database.crosshairDao())
        viewModel = ViewModelProvider(this, factory)[XForgeViewModel::class.java]

        // 4. Render main Material 3 control dashboard
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    contentWindowInsets = WindowInsets.safeDrawing
                ) { innerPadding ->
                    XForgeDashboard(
                        viewModel = viewModel,
                        modifier = Modifier.padding(innerPadding),
                        onRequestPermission = { checkAndRequestOverlayPermission() }
                    )
                }
            }
        }
    }

    /**
     * Checks if overlay draw permission is granted and prompts the user if required.
     */
    private fun checkAndRequestOverlayPermission() {
        if (!permissionManager.hasOverlayPermission()) {
            AlertDialog.Builder(this)
                .setTitle("Overlay Permission Required")
                .setMessage("To display the custom crosshair over other applications and games, X-Forge ROG requires the 'Draw over other apps' permission. Tap GRANT to open System Settings, locate X-Forge ROG, and switch it ON.")
                .setPositiveButton("GRANT") { _, _ ->
                    startActivity(permissionManager.getOverlayPermissionIntent())
                }
                .setNegativeButton("CANCEL", null)
                .show()
        } else {
            toggleOverlayService()
        }
    }

    /**
     * Toggles the Crosshair Overlay foreground service drawing status.
     */
    private fun toggleOverlayService() {
        val isActiveBefore = OverlayManager.isOverlayActive.value
        OverlayManager.toggleService(this)
        
        val msg = if (isActiveBefore) {
            "Crosshair Overlay Stopped"
        } else {
            "Crosshair Overlay Active"
        }
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
