package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.utils.Constants

/**
 * Handles basic key-value local state preferences.
 */
class PreferencesManager(context: Context) {
    private val sharedPreferences: SharedPreferences = context.getSharedPreferences(
        Constants.PREFS_NAME,
        Context.MODE_PRIVATE
    )

    fun getBoostCount(): Int {
        return sharedPreferences.getInt(Constants.KEY_BOOST_COUNT, 0)
    }

    fun incrementBoostCount() {
        val current = getBoostCount()
        sharedPreferences.edit().putInt(Constants.KEY_BOOST_COUNT, current + 1).apply()
    }
}
