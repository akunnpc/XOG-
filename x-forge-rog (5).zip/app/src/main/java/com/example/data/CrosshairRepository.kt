package com.example.data

import kotlinx.coroutines.flow.Flow

/**
 * Repository to decouple DAO operations from the presentation layer.
 */
class CrosshairRepository(private val dao: CrosshairDao) {

    val allProfiles: Flow<List<CrosshairProfile>> = dao.getAllProfiles()
    val currentProfileFlow: Flow<CrosshairProfile?> = dao.getCurrentProfileFlow()

    suspend fun getCurrentProfile(): CrosshairProfile? {
        return dao.getCurrentProfile()
    }

    suspend fun saveProfile(profile: CrosshairProfile): Long {
        return dao.insertProfile(profile)
    }

    suspend fun selectProfile(id: Int) {
        dao.clearCurrentFlags()
        dao.setCurrentProfile(id)
    }

    suspend fun clearCurrentFlags() {
        dao.clearCurrentFlags()
    }

    suspend fun deleteProfile(id: Int) {
        dao.deleteProfile(id)
    }
}
