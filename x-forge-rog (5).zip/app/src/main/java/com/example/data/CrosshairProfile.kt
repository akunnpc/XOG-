package com.example.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "crosshair_profiles")
data class CrosshairProfile(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val shape: String = "CLASSIC_X", // CLASSIC_X, DOT, SQUARE, CIRCLE
    val size: Float = 24f,
    val thickness: Float = 2f,
    val colorHex: String = "#EF4444",
    val opacity: Float = 0.85f,
    val gap: Float = 0f,
    val isCurrent: Boolean = false
)

@Dao
interface CrosshairDao {
    @Query("SELECT * FROM crosshair_profiles ORDER BY id DESC")
    fun getAllProfiles(): Flow<List<CrosshairProfile>>

    @Query("SELECT * FROM crosshair_profiles WHERE isCurrent = 1 LIMIT 1")
    fun getCurrentProfileFlow(): Flow<CrosshairProfile?>

    @Query("SELECT * FROM crosshair_profiles WHERE isCurrent = 1 LIMIT 1")
    suspend fun getCurrentProfile(): CrosshairProfile?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfile(profile: CrosshairProfile): Long

    @Query("UPDATE crosshair_profiles SET isCurrent = 0")
    suspend fun clearCurrentFlags()

    @Query("UPDATE crosshair_profiles SET isCurrent = 1 WHERE id = :id")
    suspend fun setCurrentProfile(id: Int)

    @Query("DELETE FROM crosshair_profiles WHERE id = :id")
    suspend fun deleteProfile(id: Int)
}

@Database(entities = [CrosshairProfile::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun crosshairDao(): CrosshairDao
}
