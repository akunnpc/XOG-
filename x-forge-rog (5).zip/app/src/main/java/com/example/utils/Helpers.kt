package com.example.utils

import java.util.Locale

/**
 * Utility helper functions for system metrics and general checks.
 */
object Helpers {
    /**
     * Formats memory values cleanly into GB string format.
     */
    fun formatGbSize(usedGb: Double, totalGb: Double): String {
        return String.format(Locale.US, "%.1f GB / %.1f GB", usedGb, totalGb)
    }
}
