package com.example.utils

import androidx.compose.ui.graphics.Color

/**
 * Parses a Hex Color String to a Compose Color.
 * Falls back to Red on parsing errors.
 */
fun String.toComposeColor(alpha: Float = 1.0f): Color {
    return try {
        Color(android.graphics.Color.parseColor(this)).copy(alpha = alpha)
    } catch (e: Exception) {
        Color.Red.copy(alpha = alpha)
    }
}
