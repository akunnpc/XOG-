package com.example.utils

/**
 * Global constant definitions for X-Forge ROG.
 */
object Constants {
    // Overlay Service
    const val OVERLAY_CHANNEL_ID = "xforge_crosshair_service"
    const val OVERLAY_NOTIFICATION_ID = 1337
    const val OVERLAY_SUBTYPE = "X-Forge Crosshair Overlay Service"

    // Default Crosshair Profiles
    const val SHAPE_CLASSIC_X = "CLASSIC_X"
    const val SHAPE_DOT = "DOT"
    const val SHAPE_SQUARE = "SQUARE"
    const val SHAPE_CIRCLE = "CIRCLE"

    // Database
    const val DATABASE_NAME = "xforge_rog.db"

    // Preferences
    const val PREFS_NAME = "xforge_rog_prefs"
    const val KEY_BOOST_COUNT = "boost_count"
}
