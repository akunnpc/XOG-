package com.example.permission

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings

/**
 * Manages overlay and system-level permissions for the application.
 */
class PermissionManager(private val context: Context) {

    /**
     * Checks if the System Overlay (Draw over other apps) permission is granted.
     */
    fun hasOverlayPermission(): Boolean {
        return Settings.canDrawOverlays(context)
    }

    /**
     * Generates the intent to launch the system setting page for overlay permission.
     */
    fun getOverlayPermissionIntent(): Intent {
        return Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${context.packageName}")
        )
    }
}
