package com.example.overlay

import android.content.Context
import android.content.Intent
import com.example.data.CrosshairProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Handles communication and state synchronization between MainActivity, ViewModels,
 * and the floating Crosshair Overlay Service.
 */
object OverlayManager {
    private val _currentProfile = MutableStateFlow<CrosshairProfile?>(
        CrosshairProfile(name = "CLASSIC_X", size = 24f, thickness = 2f, opacity = 0.85f, gap = 0f)
    )
    val currentProfile: StateFlow<CrosshairProfile?> = _currentProfile.asStateFlow()

    private val _isOverlayActive = MutableStateFlow(false)
    val isOverlayActive: StateFlow<Boolean> = _isOverlayActive.asStateFlow()

    // Gaming Control Center States
    private val _isPanelOpen = MutableStateFlow(false)
    val isPanelOpen: StateFlow<Boolean> = _isPanelOpen.asStateFlow()

    private val _handleSide = MutableStateFlow("RIGHT") // "LEFT" or "RIGHT"
    val handleSide: StateFlow<String> = _handleSide.asStateFlow()

    private val _handleY = MutableStateFlow(0.4f) // Percentage of screen height (0.05 to 0.95)
    val handleY: StateFlow<Float> = _handleY.asStateFlow()

    fun updateProfile(profile: CrosshairProfile?) {
        _currentProfile.value = profile
    }

    fun setOverlayActive(active: Boolean) {
        _isOverlayActive.value = active
    }

    fun setPanelOpen(open: Boolean) {
        _isPanelOpen.value = open
    }

    fun setHandleSide(side: String) {
        _handleSide.value = side
    }

    fun setHandleY(y: Float) {
        _handleY.value = y.coerceIn(0.05f, 0.95f)
    }

    /**
     * Toggles the floating overlay service on or off.
     */
    fun toggleService(context: Context) {
        val intent = Intent(context, CrosshairOverlayService::class.java)
        if (_isOverlayActive.value) {
            context.stopService(intent)
            _isPanelOpen.value = false
        } else {
            context.startService(intent)
        }
    }
}
