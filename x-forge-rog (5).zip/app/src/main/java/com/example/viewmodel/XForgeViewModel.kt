package com.example.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.CrosshairDao
import com.example.data.CrosshairProfile
import com.example.data.CrosshairRepository
import com.example.booster.BoosterManager
import com.example.overlay.OverlayManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Main Presentation ViewModel for coordinating user events, persistence, overlay synchronization,
 * and background metrics boost processing.
 */
class XForgeViewModel(
    context: Context,
    private val repository: CrosshairRepository
) : ViewModel() {

    // Manage booster subsystems
    private val boosterManager = BoosterManager(context)

    private val _currentProfile = MutableStateFlow(
        CrosshairProfile(name = "CLASSIC_X", size = 24f, thickness = 2f, colorHex = "#EF4444", opacity = 0.85f, gap = 0f)
    )
    val currentProfile: StateFlow<CrosshairProfile> = _currentProfile.asStateFlow()

    private val _savedProfiles = MutableStateFlow<List<CrosshairProfile>>(emptyList())
    val savedProfiles: StateFlow<List<CrosshairProfile>> = _savedProfiles.asStateFlow()

    // Fluctuating hardware telemetry metrics
    private val _fps = MutableStateFlow(60)
    val fps: StateFlow<Int> = _fps.asStateFlow()

    private val _cpuTemp = MutableStateFlow(38)
    val cpuTemp: StateFlow<Int> = _cpuTemp.asStateFlow()

    // Delegate flows to booster manager
    val ramUsage: StateFlow<String> = boosterManager.ramUsage
    val isBoosting: StateFlow<Boolean> = boosterManager.isBoosting
    val boostProgress: StateFlow<Float> = boosterManager.boostProgress

    init {
        // Collect DB changes and notify overlay
        viewModelScope.launch {
            repository.allProfiles.collect { list ->
                _savedProfiles.value = list
                val current = list.find { it.isCurrent }
                if (current != null) {
                    _currentProfile.value = current
                    OverlayManager.updateProfile(current)
                } else if (list.isNotEmpty()) {
                    val first = list.first()
                    _currentProfile.value = first.copy(isCurrent = true)
                    repository.selectProfile(first.id)
                    OverlayManager.updateProfile(first)
                } else {
                    // Seed database presets on first boot
                    seedPresets()
                }
            }
        }

        // Active background updater loop for system telemetry metrics
        viewModelScope.launch {
            while (true) {
                boosterManager.updateMemoryStats()
                _fps.value = (58..62).random()
                _cpuTemp.value = (36..41).random()
                delay(2000)
            }
        }
    }

    private suspend fun seedPresets() {
        val defaultPreset = CrosshairProfile(name = "Classic Red", shape = "CLASSIC_X", size = 24f, thickness = 2f, colorHex = "#EF4444", opacity = 0.85f, gap = 0f, isCurrent = true)
        val dotPreset = CrosshairProfile(name = "Toxic Dot", shape = "DOT", size = 12f, thickness = 4f, colorHex = "#10B981", opacity = 0.95f, gap = 0f, isCurrent = false)
        val squarePreset = CrosshairProfile(name = "Cyber Square", shape = "SQUARE", size = 30f, thickness = 2f, colorHex = "#06B6D4", opacity = 0.8f, gap = 4f, isCurrent = false)
        val circlePreset = CrosshairProfile(name = "Halo Ring", shape = "CIRCLE", size = 40f, thickness = 3f, colorHex = "#EAB308", opacity = 0.75f, gap = 6f, isCurrent = false)

        val defId = repository.saveProfile(defaultPreset).toInt()
        repository.saveProfile(dotPreset)
        repository.saveProfile(squarePreset)
        repository.saveProfile(circlePreset)

        val updatedDefault = defaultPreset.copy(id = defId)
        _currentProfile.value = updatedDefault
        OverlayManager.updateProfile(updatedDefault)
    }

    fun updateShape(shape: String) {
        val updated = _currentProfile.value.copy(shape = shape)
        _currentProfile.value = updated
        OverlayManager.updateProfile(updated)
        saveCurrentConfigDebounced(updated)
    }

    fun updateSize(size: Float) {
        val updated = _currentProfile.value.copy(size = size)
        _currentProfile.value = updated
        OverlayManager.updateProfile(updated)
        saveCurrentConfigDebounced(updated)
    }

    fun updateThickness(thickness: Float) {
        val updated = _currentProfile.value.copy(thickness = thickness)
        _currentProfile.value = updated
        OverlayManager.updateProfile(updated)
        saveCurrentConfigDebounced(updated)
    }

    fun updateColor(colorHex: String) {
        val updated = _currentProfile.value.copy(colorHex = colorHex)
        _currentProfile.value = updated
        OverlayManager.updateProfile(updated)
        saveCurrentConfigDebounced(updated)
    }

    fun updateOpacity(opacity: Float) {
        val updated = _currentProfile.value.copy(opacity = opacity)
        _currentProfile.value = updated
        OverlayManager.updateProfile(updated)
        saveCurrentConfigDebounced(updated)
    }

    fun updateGap(gap: Float) {
        val updated = _currentProfile.value.copy(gap = gap)
        _currentProfile.value = updated
        OverlayManager.updateProfile(updated)
        saveCurrentConfigDebounced(updated)
    }

    private fun saveCurrentConfigDebounced(profile: CrosshairProfile) {
        viewModelScope.launch {
            repository.saveProfile(profile)
        }
    }

    fun selectProfile(profile: CrosshairProfile) {
        viewModelScope.launch {
            repository.selectProfile(profile.id)
            val updated = profile.copy(isCurrent = true)
            _currentProfile.value = updated
            OverlayManager.updateProfile(updated)
            repository.saveProfile(updated)
        }
    }

    fun createAndSaveNewProfile(name: String) {
        viewModelScope.launch {
            repository.clearCurrentFlags()
            val newProfile = _currentProfile.value.copy(
                id = 0,
                name = name,
                isCurrent = true
            )
            val newId = repository.saveProfile(newProfile).toInt()
            val savedProfile = newProfile.copy(id = newId)
            _currentProfile.value = savedProfile
            OverlayManager.updateProfile(savedProfile)
        }
    }

    fun deleteProfile(profile: CrosshairProfile) {
        viewModelScope.launch {
            if (profile.isCurrent) {
                val remaining = _savedProfiles.value.filter { it.id != profile.id }
                if (remaining.isNotEmpty()) {
                    selectProfile(remaining.first())
                }
            }
            repository.deleteProfile(profile.id)
        }
    }

    fun triggerMemoryBoost() {
        viewModelScope.launch {
            boosterManager.executeMemoryBoost()
        }
    }
}

/**
 * Custom Factory class as required to pass Context and Repository arguments to ViewModel.
 */
class XForgeViewModelFactory(
    private val context: Context,
    private val dao: CrosshairDao
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(XForgeViewModel::class.java)) {
            val repository = CrosshairRepository(dao)
            @Suppress("UNCHECKED_CAST")
            return XForgeViewModel(context, repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
