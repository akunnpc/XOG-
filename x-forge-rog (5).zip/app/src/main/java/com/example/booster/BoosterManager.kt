package com.example.booster

import android.content.Context
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Coordinates and manages the state of system memory boosting tasks.
 */
class BoosterManager(context: Context) {
    private val ramBooster = RamBooster(context)

    private val _isBoosting = MutableStateFlow(false)
    val isBoosting: StateFlow<Boolean> = _isBoosting.asStateFlow()

    private val _boostProgress = MutableStateFlow(0f)
    val boostProgress: StateFlow<Float> = _boostProgress.asStateFlow()

    private val _ramUsage = MutableStateFlow("0.0 GB / 0.0 GB")
    val ramUsage: StateFlow<String> = _ramUsage.asStateFlow()

    init {
        updateMemoryStats()
    }

    /**
     * Refreshes the memory usage stats flow.
     */
    fun updateMemoryStats() {
        _ramUsage.value = ramBooster.getFormattedMemoryUsage()
    }

    /**
     * Simulates background process cleaning & runs GC, updating progress.
     */
    suspend fun executeMemoryBoost(onStep: suspend (Float) -> Unit = {}) {
        if (_isBoosting.value) return
        
        _isBoosting.value = true
        _boostProgress.value = 0f
        
        // Execute core clean
        ramBooster.performGarbageCollection()

        // Progression feedback for UI polish
        for (i in 1..10) {
            val progress = i / 10f
            _boostProgress.value = progress
            onStep(progress)
            delay(120)
        }

        updateMemoryStats()
        _isBoosting.value = false
        _boostProgress.value = 0f
    }
}
