package com.example.state

/**
 * Representing UI States and status wrappers for X-Forge ROG.
 */
data class SystemStatsState(
    val fps: Int = 60,
    val cpuTemp: Int = 38,
    val ramUsage: String = "3.2 GB / 8.0 GB"
)

data class BoosterState(
    val isBoosting: Boolean = false,
    val progress: Float = 0f
)
