package com.example.overlay

import android.content.Context
import android.content.Intent
import com.example.data.CrosshairProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Handles communication and state synchronization between MainActivity, ViewModels,
 * and the floating Crosshair Overlay Service.
 */
object OverlayManager {
    private val _currentProfile = MutableStateFlow<CrosshairProfile?>(
        CrosshairProfile(name = "CLASSIC_X", size = 24f, thickness = 2f, opacity = 0.85f, gap = 0f)
    )
    val currentProfile: StateFlow<CrosshairProfile?> = _currentProfile.asStateFlow()

    private val _isOverlayActive = MutableStateFlow(false)
    val isOverlayActive: StateFlow<Boolean> = _isOverlayActive.asStateFlow()

    fun updateProfile(profile: CrosshairProfile?) {
        _currentProfile.value = profile
    }

    fun setOverlayActive(active: Boolean) {
        _isOverlayActive.value = active
    }

    /**
     * Toggles the floating overlay service on or off.
     */
    fun toggleService(context: Context) {
        val intent = Intent(context, CrosshairOverlayService::class.java)
        if (_isOverlayActive.value) {
            context.stopService(intent)
        } else {
            context.startService(intent)
        }
    }
}
